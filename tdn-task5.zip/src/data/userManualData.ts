/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface ManualSection {
  id: string;
  name: string;
  icon: string;
  objective: string;
  forSếp: string;
  forAdmin: string;
  forCS: string;
  howToUse: string[];
}

export const USER_MANUAL_SECTIONS: ManualSection[] = [
  {
    id: 'dashboard',
    name: 'Bàn Làm Việc (Tổng Quan)',
    icon: 'LayoutDashboard',
    objective: 'Cung cấp cái nhìn bao quát về tình hình hoạt động của công ty Tín Dân, số liệu KPI, biểu đồ tiến độ dự án nhãn tem Vivian, và thông báo hệ thống mới nhất.',
    forSếp: 'Theo dõi tổng quan doanh số hoặc năng suất xưởng, xem nhanh các cảnh báo về rủi ro trễ hạn dự án do AI phân tích.',
    forAdmin: 'Kiểm soát nhịp độ công việc của các phòng ban, theo dõi các bình luận trao đổi mới của CS và Xưởng.',
    forCS: 'Xem nhanh danh sách công việc của mình cần hoàn thành trong ngày và các thông báo khẩn từ cấp trên.',
    howToUse: [
      'Giao diện bento-grid hiển thị trực quan các thẻ báo cáo nhanh.',
      'Sử dụng biểu đồ Tiến độ / Trạng thái dự án để điều phối kế hoạch sản xuất xưởng in màng sấy UV.',
      'Theo dõi bảng tin bình luận thời gian thực để không bỏ sót tương tác phối hợp.'
    ]
  },
  {
    id: 'tasks',
    name: 'Quản Lý Công Việc (Đồng Bộ Live)',
    icon: 'CheckSquare',
    objective: 'Module trọng tâm cập nhật liên tục mọi trạng thái của các lệnh in ấn, bế nhãn, và tương tác của xưởng.',
    forSếp: 'Giám sát chi tiết ai đang làm gì, phê duyệt kết quả công việc tức thì, cập nhật chỉ đạo khẩn.',
    forAdmin: 'Tạo công việc mới, phân bổ cho nhân viên xưởng hoặc CS, thiết lập mức độ ưu tiên (Cao, Trung bình, Thấp) và gán thời hạn (Deadline).',
    forCS: 'Nhận nhiệm vụ, cập nhật tiến độ (Chờ xử lý, Đang làm, Hoàn thành), phản hồi qua ô bình luận dưới mỗi thẻ công việc.',
    howToUse: [
      'Nhấn "Thêm công việc" để tạo mới (Admin/Super Admin).',
      'Kéo thả trạng thái hoặc click chọn cập nhật trực tiếp tiến độ.',
      'Đặc biệt: Module này tự chọn kích hoạt đồng bộ đám mây liên tục. Khi một CS/Admin khác cập nhật dữ liệu mới lên Firestore, màn hình của mọi người trong bộ phận sẽ lập tức hiển thị thay đổi tự động.'
    ]
  },
  {
    id: 'projects',
    name: 'Quản Lý Dự Án',
    icon: 'FolderKanban',
    objective: 'Quản trị các dự án nhãn sản phẩm lớn, đơn hàng máy sấy khô UV Vivian, hoặc chiến dịch Marketing màng dán chống giả.',
    forSếp: 'Xem báo cáo rủi ro dự án bằng AI (AI Risk Scoring) để biết dự án nào có nguy cơ bị chậm hoặc gặp trục trặc.',
    forAdmin: 'Điều phối toàn diện, gắn kết các đầu việc nhỏ trong Module Công Việc vào một dự án tổng thể.',
    forCS: 'Thực thi các chuỗi tác vụ phối hợp theo tiến trình từng giai đoạn dự án.',
    howToUse: [
      'Xem danh mục dự án, bấm xem chi tiết từng dự án để kiểm tra tiến trình phần trăm.',
      'AI sẽ tự tính toán điểm rủi ro trễ hạn dựa vào thời gian còn lại và số lượng việc tồn đọng.'
    ]
  },
  {
    id: 'excel-import',
    name: 'AI Nhập Excel Thông Minh',
    icon: 'FileSpreadsheet',
    objective: 'Giảm thiểu thao tác nhập thủ công cực nhọc cho CS và Admin bằng cách kéo thả file excel đơn hàng hoặc lệnh sản xuất vào hệ thống, AI sẽ tự bóc tách và tạo việc loạt.',
    forSếp: 'Kiểm tra tỷ lệ xử lý đúng dữ liệu của AI, tinh gọn quy trình giấy tờ xưởng in.',
    forAdmin: 'Kéo thả file .xlsx danh sách đơn hàng tem nhãn nhận từ đối tác lớn, hệ thống tự động bóc tách và import vào cơ sở dữ liệu xưởng.',
    forCS: 'Nhập nhanh danh sách khách hàng để chat Zalo OA chăm sóc một cách tự động.',
    howToUse: [
      'Tải tệp Excel mẫu hoặc dùng định dạng cột tiêu chuẩn (Tên công việc, Người nhận, Phòng ban, Deadline...)',
      'Kéo thả file vào khung tải lên hoặc chọn từ máy tính.',
      'Nhấn "Xử lý bằng AI" để hệ thống tự động chiết xuất các hàng/cột và đưa vào CRM.'
    ]
  },
  {
    id: 'reports',
    name: 'AI Báo Cáo & Phân Tích',
    icon: 'FileBox',
    objective: 'Báo cáo thông minh hoàn toàn tự động bằng trí tuệ nhân tạo Gemini, xuất các khuyến nghị Growth Hacking thực chiến.',
    forSếp: 'Nhận báo cáo phân tích hiệu suất xưởng in, tỷ lệ hoàn thành KPI các phòng ban mà không cần ngồi tự cộng trừ số liệu.',
    forAdmin: 'Xuất báo cáo hàng tuần cực nhanh để nộp cho Sếp Tuấn Anh.',
    forCS: 'Theo dõi sự cố hoặc thành tích đạt được của cá nhân và đội nhóm.',
    howToUse: [
      'Bấm nút "Tạo báo cáo mới bằng AI", hệ thống sẽ quét Cơ sở dữ liệu và chuyển về mô hình ngôn ngữ lớn để diễn giải.',
      'Hệ thống sẽ cho ra các biểu đồ năng lực, đánh giá kẽ hở năng suất và đưa ra giải pháp Conversion Rate Optimization (CRO) thiết thực.'
    ]
  },
  {
    id: 'kpis',
    name: 'Chỉ Số KPI Doanh Nghiệp',
    icon: 'TrendingUp',
    objective: 'Thiết lập các mốc chỉ tiêu doanh số bán máy sấy Vivian, số cuộn màng UV giao thành công, hay tốc độ phản hồi CSKH.',
    forSếp: 'Khoán chỉ tiêu khoa học cho nhân viên, kiểm tra mức độ đạt chỉ tiêu theo thời gian thực.',
    forAdmin: 'Cập nhật số liệu thực tế cho từng nhân sự / phòng ban để đo lường phần trăm hoàn thành KPI.',
    forCS: 'Nỗ lực đạt được chỉ số đề ra, theo dõi bảng xếp hạng vinh danh thi đua nội bộ.',
    howToUse: [
      'Bảng chỉ số KPI chia rõ ràng mục tiêu, thực tế đạt được, mức độ tiến triển.',
      'Cập nhật thủ công hoặc để hệ thống tự động tổng hợp từ Module Công việc đã hoàn thành.'
    ]
  },
  {
    id: 'duyen-chatbot',
    name: 'Chatbot Duyên - AI Growth Hacker',
    icon: 'Sparkles',
    objective: 'Hiện thân của Trợ lý Số Duyên AI thông minh, am hiểu sâu sắc quy chuẩn xưởng in Tín Dân và các bí thuật tối ưu hóa phễu tăng trưởng ROI.',
    forSếp: 'Chỉ đạo Duyên AI lập chiến lược tiếp cận khách hàng tiềm năng, soạn thảo văn bản hoặc kịch bản Livestream tem Vivian.',
    forAdmin: 'Hỏi đáp nghiệp vụ xưởng in, cách khắc phục lỗi sấy UV, tra cứu tài liệu kỹ thuật nhanh.',
    forCS: 'Nhờ Duyên soạn kịch bản tư vấn khách hàng, trả lời tin nhắn Fanpage/Zalo mượt mà, chuyên nghiệp.',
    howToUse: [
      'Nhập câu hỏi hoặc yêu cầu trực tiếp vào ô chat của Chatbot Duyên.',
      'Sử dụng các câu lệnh gợi ý có sẵn như "Soạn kịch bản tư vấn", "Giải phóng rủi ro trễ hạn", "Đề xuất chiến lược tăng ROI Tín Dân".'
    ]
  },
  {
    id: 'zalo-oa',
    name: 'Trung Tâm Zalo OA Chăm Sóc Khách Hàng',
    icon: 'Briefcase',
    objective: 'Kênh tương tác trực tiếp với khách hàng qua Zalo Official Account, gửi tin nhắn chăm sóc tự động hàng loạt.',
    forSếp: 'Đánh giá hiệu quả chiến dịch gửi tin nhắn hàng loạt (Zalo Broadcast), kiểm soát kịch bản truyền thông.',
    forAdmin: 'Quản trị các Token API kết nối Zalo, thiết lập kịch bản chăm sóc sau khi khách mua decal cuộn.',
    forCS: 'Gửi tin nhắn mẫu, chat trực tiếp với danh sách khách hàng từ CRM đổ sang.',
    howToUse: [
      'Cấu hình mã ID Zalo OA trong mục Thiết lập hoặc Zalo OA.',
      'Sử dụng công cụ Gửi Tin hàng loạt cho tệp khách hàng theo bộ lọc phòng ban.'
    ]
  }
];

export const RAW_MARKDOWN_MANUAL = `# TÀI LIỆU HƯỚNG DẪN SỬ DỤNG HỆ ĐIỀU HÀNH TÍN DÂN CRM (VIVIAN SYSTEM v1.0)
---
## I. GIỚI THIỆU CHUNG & MỤC TIÊU DỰ ÁN
**Hệ thống Tín Dân CRM | Vivian AI Operating System** là cổng điều hành số nội bộ tối tân của **Tín Dân Company** (temvivian.vn), được thiết kế để giải quyết triệt để bài toán:
1. **Quản lý toàn diện**: Đồng bộ hóa luồng công việc giữa bộ phận Kinh Doanh (đơn hàng xưởng nhãn, tem cuộn sấy UV Vivian), bộ phận Thiết kế, Admin và đội ngũ CSKH.
2. **Growth Hacking tích hợp Trợ lý Số (Duyên AI)**: Ứng dụng trí tuệ nhân tạo Gemini để bóc tách file Excel đơn hàng xưởng, tự động hóa kịch bản Zalo OA chăm sóc, lập báo cáo phân tích ROI & rủi ro trễ tiến độ xưởng sấy.
3. **Tiết kiệm tối đa hạ tầng (Supabase Performance Optimization)**:
   * **Đồng bộ hành vi tự động**: Hệ thống không tải dữ liệu đám mây vô định. Dữ liệu chỉ được truy vấn từ Supabase Database đúng lúc người dùng đang mở Module đó. Khi chuyển sang Module khác, luồng tải sẽ dừng ngay.
   * **Đồng bộ thời gian thực cho Module "Công Việc"**: Chỉ riêng Module "Công Việc" được trang bị chế độ auto-update live khi có tác vụ hay người dùng mới gửi tải lên, giúp toàn xưởng luôn đồng bộ lệch in tức thời mà không tốn tài nguyên.
   * **Cập nhật chủ động**: Các sự kiện sửa/xóa/cập nhật mới bất kỳ của người dùng đều được ghi nhận và up trực tiếp lên đám mây ngay lập tức.

---

## II. DANH SÁCH TÀI KHOẢN TRUY CẬP ĐỊNH SẴN (QUYỀN HẠN)
Để bắt đầu đăng nhập hệ thống, vui lòng sử dụng danh sách tài khoản định cấu hình sẵn dưới đây:

### 1. Tài Khoản Quản Trị Tối Cao (SUPER_ADMIN)
* **Email**: \`tindancompany22@gmail.com\`
* **Mật khẩu**: \`admin\`
* **Chức danh**: Sếp Trần Tuấn Anh (Sếp Tín Dân)
* **Quyền hạn**: Kiểm soát toàn quyền tất cả các modules, quản lý thành viên, cấu hình cài đặt, xem báo cáo AI, khoán KPI.

### 2. Tài Khoản Quản Lý / Thành Viên Cấp Cao (ADMIN)
* **Email**: \`tuananhcdv\`
* **Mật khẩu**: \`tdn@1234!\`
* **Chức danh**: Trần Tuấn Anh (CDV) / Quản lý vận hành
* **Quyền hạn**: Tạo/Sửa/Xóa công việc, giao việc, gán chỉ số KPI phòng ban, quản lý tài liệu quy chuẩn kỹ thuật xưởng in.

### 3. Tài Khoản Nhân Viên / Chăm Sóc Khách Hàng (EMPLOYEE)
* **Email**: \`nhanvien@tindan.com\`
* **Mật khẩu**: \`123456\`
* **Chức danh**: CSKH / Nhân viên xưởng sấy UV
* **Quyền hạn**: Xem danh sách công việc được giao, bình luận thảo luận tiến độ, cập nhật hoàn thành, chat hỏi ý kiến Duyên AI, tải tài liệu xưởng màng sấy UV.

---

## III. HƯỚNG DẪN SỬ DỤNG CHI TIẾT TỪNG PHÂN HỆ (MODULE)

### 1. Bàn Làm Việc (Dashboard)
* **Chức năng**: Nơi theo dõi trực quan trạng thái sức khỏe doanh nghiệp thông qua bento-grid.
* **Cách sử dụng cho người mới**:
  1. Kiểm tra 4 thẻ chỉ số chính: Tổng công việc, Dự án đang chạy, Tỷ lệ hoàn thành và Cảnh báo trễ hại.
  2. Xem biểu đồ cột/tròn thể hiện trực quan phân bổ kế hoạch decal màng Vivian.
  3. Đọc khung "Bình luận trao đổi phối hợp xưởng" bên phải để nắm thông tin thảo luận nóng.

### 2. Quản Lý Công Việc (Đồng Bộ Live)
* **Đặc tính độc quyền**: Là module tự động cập nhật ngay khi có thay đổi từ máy trạm khác.
* **Quy trình vận hành chuẩn**:
  * **Tạo mới**: Admin nhấn nút **"Thêm công việc"** -> Nhập tên việc (Ví dụ: "Sấy đèn UV lô decal Vivian số 12") -> Chọn phòng ban chịu trách nhiệm (Thiết kế / Kỹ thuật / CSKH) -> Gán người thực hiện -> Thiết lập Hạn chót & Mức ưu tiên -> Lưu lên đám mây.
  * **Cập nhật trạng thái**: Click vào cột Trạng thái (Chờ xử lý, Đang làm, Hoàn thành) của thẻ công việc để hệ thống tự động dịch chuyển và đồng bộ đám mây tức thì.
  * **Xóa công việc**: Với quyền Admin, nhấn vào biểu tượng **Thùng Rác** ở góc thẻ công việc để xóa vĩnh viễn khỏi Supabase Database.

### 3. Quản Lý Dự Án & Đơn Hàng Tem Nhãn
* **Chức năng**: Nhóm các công việc rời rạc lại thành một mục tiêu đơn hàng nhãn Vivian lớn (Ví dụ: "Hợp đồng nhãn sấy khô UV Vivian tẩm sấy cuộn").
* **Cách sử dụng**:
  1. Nhấn nút **"Thêm dự án"** -> Nhập tên, mô tả và chọn thời hạn bàn giao.
  2. Bấm vào chi tiết để xem AI tự tính toán **Điểm rủi ro trễ tiến độ (AI Risk Score)** dựa trên thuật toán tích lũy ngày cận kề và số lượng tác vụ còn kẹt.

### 4. AI Nhập Excel Tiết Kiệm Thao Tác
* **Mục tiêu**: Giải phóng 90% thời gian nhập liệu đơn hàng sấy UV của nhân viên CS.
* **Cách sử dụng**:
  1. Nhấn vào module **AI Nhập Excel**.
  2. Kéo thả file Excel chứa nhiều hàng đơn hàng hoặc click chọn file từ máy tính.
  3. Chờ AI Gemini hỗ trợ phân tích định dạng các cột và bấm **"Import loạt việc"** để nạp thẳng lên Supabase đám mây.

### 5. Chỉ Số KPI Doanh Nghiệp
* **Chức năng**: Đảm bảo công bằng trong kiểm tra năng lực nhân sự.
* **Cách sử dụng**:
  1. Sếp Tuấn Anh thiết lập mức KPI mong muốn (Ví dụ: "In 50,000 m cuộn") cho phòng Kỹ thuật.
  2. Hệ thống CRM tự hiển thị dải đo độ hoàn thành (%).
  3. Nhân sự chủ động xem để chuẩn bị báo cáo tuần/tháng.

### 6. Chatbot Duyên - AI Growth Hacker
* **Chức năng**: Sử dụng mô hình AI tối tân để trả lời tin nhắn điều hành, thiết kế ý tưởng tem dán chống giả Vivian.
* **Cách sử dụng**:
  1. Bấm vào **Chatbot Duyên** ở thanh điều hướng.
  2. Nhấn vào các phím tắt hỏi nhanh như "Tăng ROI cho xưởng Tín Dân", "Màng sấy UV Vivian là gì?".
  3. Trò chuyện tương tác với văn phong cá tính, thông minh, chuyên nghiệp dành cho doanh nghiệp in ấn.

---

## IV. BỘ NÚT TÍNH NĂNG "CỨU HỘ ĐƯỜNG TRUYỀN" MỚI (TRÊN THANH STATUS)
Để sếp và nhân viên an tâm vận hành tuyệt đối không sợ sự cố trễ kết nối mạng 4G/Wifi, CRM đã trang bị độc quyền bộ nút bấm trên đầu trang:
1. **Pill Trạng Thái "LIVE CONNECTION"**: Biểu báo đèn nhấp nháy xác tín đường truyền Supabase của AI Studio đang thông suốt.
2. **Nút "Đồng bộ CRM"**: Bấm vào bất kỳ lúc nào để ép hệ thống CRM quét quét lại toàn bộ cơ sở dữ liệu trên đám mây Supabase, đảm bảo đồng nhất 100% dữ liệu nếu mạng của Sếp bị rớt tạm thời.
3. **Nút "Làm mới truyền tải"**: Tự động giải phóng bộ nhớ đệm (Local Cache) bị kẹt và kết nối thử lại (Refresh channel to Supabase) tức thì.

---
**TM. BAN ĐIỀU HÀNH TÍN DÂN CRM**
* Vivian Label System - Kiến tạo giải pháp in cuộn tối tân*
`;
