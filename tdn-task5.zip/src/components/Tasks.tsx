import React, { useState, useEffect } from 'react';
import { 
  Plus, Search, Kanban, List as ListIcon, Calendar as CalendarIcon, 
  Sparkles, Clock, Users, GitBranch, 
  AlertTriangle, CornerDownRight, CheckSquare, Zap,
  Award, ShieldAlert
} from 'lucide-react';
import { User, Task, Project } from '../types';
import { useTaskStore } from '../lib/taskStore';
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid } from 'recharts';
import { motion, AnimatePresence } from 'motion/react';

interface TasksProps {
  currentUser: User;
  users: User[];
  projects: Project[];
}

export default function Tasks({ currentUser, users, projects }: TasksProps) {
  const { 
    tasks, fetchTasks, addTask, updateTask, deleteTask, 
    addComment, addSubtask, toggleSubtask 
  } = useTaskStore();

  const [viewMode, setViewMode] = useState<'kanban' | 'list' | 'calendar' | 'timeline' | 'workload' | 'aipriority'>('kanban');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedDeptFilter, setSelectedDeptFilter] = useState('All');

  // Popup management
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [selectedTask, setSelectedTask] = useState<Task | null>(null);

  // Task creation fields
  const [newTitle, setNewTitle] = useState('');
  const [newDesc, setNewDesc] = useState('');
  const [newAssignee, setNewAssignee] = useState(currentUser.name);
  const [newDept, setNewDept] = useState(currentUser.department || 'Tăng Trưởng');
  const [newPriority, setNewPriority] = useState<'low' | 'medium' | 'high' | 'critical'>('medium');
  const [newDueDate, setNewDueDate] = useState('2026-06-20');
  const [newStartDate, setNewStartDate] = useState('2026-06-12');
  const [newEstHours, setNewEstHours] = useState(8);
  const [newKpiWeight, setNewKpiWeight] = useState(40);
  const [newSlaLevel, setNewSlaLevel] = useState<'low' | 'medium' | 'high' | 'critical'>('medium');
  const [newDependency, setNewDependency] = useState('');

  // Edit mode inside modal
  const [isEditingTask, setIsEditingTask] = useState(false);
  const [editTitle, setEditTitle] = useState('');
  const [editDesc, setEditDesc] = useState('');
  const [editDept, setEditDept] = useState('');
  const [editAssignee, setEditAssignee] = useState('');
  const [editPriority, setEditPriority] = useState<'low' | 'medium' | 'high' | 'critical'>('medium');
  const [editDueDate, setEditDueDate] = useState('');
  const [editStartDate, setEditStartDate] = useState('');
  const [editEstHours, setEditEstHours] = useState(8);
  const [editKpiWeight, setEditKpiWeight] = useState(40);
  const [editSlaLevel, setEditSlaLevel] = useState<'low' | 'medium' | 'high' | 'critical'>('medium');
  const [editFollowers, setEditFollowers] = useState<string[]>([]);
  const [editCreator, setEditCreator] = useState('');

  useEffect(() => {
    if (selectedTask) {
      setEditTitle(selectedTask.title || '');
      setEditDesc(selectedTask.description || '');
      setEditDept(selectedTask.department || 'Tăng Trưởng');
      setEditAssignee(selectedTask.assignedTo || '');
      setEditPriority(selectedTask.priority || 'medium');
      setEditDueDate(selectedTask.dueDate || '');
      setEditStartDate(selectedTask.start_date || selectedTask.createdAt?.split('T')[0] || '2026-06-12');
      setEditEstHours(selectedTask.estimated_hours || 8);
      setEditKpiWeight(selectedTask.KPI_weight || 40);
      setEditSlaLevel(selectedTask.SLA_level || 'medium');
      setEditFollowers(selectedTask.followers || []);
      setEditCreator(selectedTask.creator || selectedTask.createdBy || 'Trần Tuấn Anh (Sếp)');
      setIsEditingTask(false);
    }
  }, [selectedTask]);

  // Local comments / subtask states
  const [commentInput, setCommentInput] = useState('');
  const [subtaskInput, setSubtaskInput] = useState('');

  const [statusTimeFilter, setStatusTimeFilter] = useState<'all' | 'done' | 'doing' | 'overdue' | 'near_overdue'>('all');
  const todayStr = '2026-06-12';

  // AI intelligence states
  const [aiAnalyzing, setAiAnalyzing] = useState(false);
  const [aiFeedback, setAiFeedback] = useState<string | null>(null);
  const [aiAnalysisResult, setAiAnalysisResult] = useState<any | null>(null);

  // Automation logs
  const automationLogs = [
    "Dịch vụ kích hoạt: Overdue → Gửi cảnh báo Telegram cho sếp Tuấn Anh",
    "Dịch vụ kích hoạt: Completed → Mở khóa chuỗi phụ thuộc tuyến sau",
  ];

  useEffect(() => {
    fetchTasks();
  }, [fetchTasks]);

  // Filters logic
  const filteredTasks = tasks.filter(t => {
    const matchesSearch = t.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          t.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          t.assignedTo.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesDept = selectedDeptFilter === 'All' || t.department === selectedDeptFilter;

    let matchesStatusTime = true;
    if (statusTimeFilter === 'done') {
      matchesStatusTime = t.status === 'done';
    } else if (statusTimeFilter === 'doing') {
      matchesStatusTime = t.status !== 'done';
    } else if (statusTimeFilter === 'overdue') {
      matchesStatusTime = t.status !== 'done' && !!t.dueDate && t.dueDate < todayStr;
    } else if (statusTimeFilter === 'near_overdue') {
      const isOverdue = t.status !== 'done' && !!t.dueDate && t.dueDate < todayStr;
      const isNear = t.status !== 'done' && !!t.dueDate && t.dueDate >= todayStr && 
                     (new Date(t.dueDate).getTime() - new Date(todayStr).getTime()) <= 2 * 24 * 3600 * 1000;
      matchesStatusTime = isNear && !isOverdue;
    }

    // Security visibility: only direct personnel and related personnel can view. Admins see everything.
    const isAdmin = currentUser.id === '1' || currentUser.role === 'Admin' || currentUser.name.toLowerCase().includes('sếp');
    const isAssigned = t.assignedTo === currentUser.name;
    const isFollower = t.followers?.includes(currentUser.name);
    const isCreator = t.creator === currentUser.name || t.createdBy === currentUser.name;
    const isVisible = isAdmin || isAssigned || isFollower || isCreator;

    return matchesSearch && matchesDept && matchesStatusTime && isVisible;
  });

  // Realtime typing simulator
  const [typingIndicator, setTypingIndicator] = useState<string | null>(null);
  useEffect(() => {
    const usersList = ["Mỹ Duyên AI", "Nam Tăng Trưởng", "Nguyễn Văn Đạt"];
    const interval = setInterval(() => {
      if (Math.random() > 0.6) {
        const randomUser = usersList[Math.floor(Math.random() * usersList.length)];
        setTypingIndicator(`${randomUser} đang gõ bình luận sản phẩm...`);
        setTimeout(() => setTypingIndicator(null), 3000);
      }
    }, 8000);
    return () => clearInterval(interval);
  }, []);

  // AI: Run comprehensive workflow audit
  const runWorkflowAudit = async () => {
    setAiAnalyzing(true);
    setAiFeedback(null);
    try {
      const res = await fetch('/api/ai/workflow-analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ tasks, members: users }),
      });
      const data = await res.json();
      if (data.success && data.data) {
        setAiAnalysisResult(data.data);
      }
    } catch (err: any) {
      console.error(err);
    } finally {
      setAiAnalyzing(false);
    }
  };

  // AI: Recalculate intelligent priority scores
  const recalculateAiScores = async () => {
    setAiAnalyzing(true);
    setAiFeedback("Đang khởi động Smart Priority Engine để đo đạc SLA & chỉ số KPI...");
    try {
      const res = await fetch('/api/ai/prioritize-tasks', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ tasks }),
      });
      const data = await res.json();
      if (data.success && data.data) {
        // Apply AI scores to store
        data.data.forEach((scoreObj: any) => {
          const taskObj = tasks.find(t => t.id === scoreObj.taskId);
          if (taskObj) {
            updateTask({
              ...taskObj,
              AI_score: scoreObj.AI_score,
              labels: [...new Set([...(taskObj.labels || []), 'AI-Smart'])]
            });
          }
        });
        setAiFeedback("Đã cập nhật điểm số rủi ro AI Priority Score thành công!");
      }
    } catch (err: any) {
      console.error(err);
    } finally {
      setAiAnalyzing(false);
    }
  };

  const handleCreateTask = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;

    const taskObj: Task = {
      id: 'task_' + Date.now(),
      title: newTitle,
      description: newDesc,
      status: 'todo',
      priority: newPriority,
      dueDate: newDueDate,
      assignedTo: newAssignee,
      projectId: projects[0]?.id || 'p1',
      progress: 0,
      department: newDept,
      start_date: newStartDate,
      estimated_hours: Number(newEstHours),
      KPI_weight: Number(newKpiWeight),
      SLA_level: newSlaLevel,
      dependencies: newDependency ? [newDependency] : [],
      subtasks: [],
      attachments: [],
      comments: [],
      activity_logs: [],
    };

    await addTask(taskObj);
    setShowCreateModal(false);
    setNewTitle('');
    setNewDesc('');
    setNewDependency('');
    setNewEstHours(8);
  };

  const checkDependencyBlocked = (task: Task): boolean => {
    if (!task.dependencies || task.dependencies.length === 0) return false;
    return task.dependencies.some(depId => {
      const depTask = tasks.find(t => t.id === depId);
      return depTask ? depTask.status !== 'done' : false;
    });
  };

  // Recharts Helper Data
  const getWorkloadChartData = () => {
    const allocation: { [name: string]: number } = {};
    users.forEach(u => { allocation[u.name] = 0; });
    tasks.forEach(t => {
      if (t.status !== 'done' && allocation[t.assignedTo] !== undefined) {
        allocation[t.assignedTo] += t.estimated_hours || 8;
      }
    });
    return Object.keys(allocation).map(name => ({
      name,
      'Số giờ đã giao (Giờ)': allocation[name],
      'Hạn mức năng lực (Max)': 40
    }));
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto px-4 md:px-6 font-sans transition-colors duration-300 text-slate-100">
      
      {/* 1. Header & Live Dashboard Cards */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 border-b border-slate-800/60 pb-5">
        <div>
          <h1 className="text-xl md:text-2xl font-extrabold tracking-tight bg-gradient-to-r from-emerald-400 via-blue-400 to-indigo-400 bg-clip-text text-transparent">
            MODULE 1 — ENTERPRISE FLOW & AI WORKFLOW
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Trực quan hóa khối lượng, tiến độ và giải quyết tắc nghẽn thông minh bởi Mỹ Duyên AI.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          {/* AI Score trigger */}
          <button
            onClick={recalculateAiScores}
            disabled={aiAnalyzing}
            className="px-3.5 py-2 bg-indigo-600/20 border border-indigo-500/40 text-indigo-300 text-xs font-bold rounded-lg hover:bg-indigo-600/30 transition flex items-center gap-1.5"
          >
            <Sparkles className="w-3.5 h-3.5 text-indigo-400 animate-pulse" />
            <span>Smart Priority</span>
          </button>

          <button
            onClick={() => setShowCreateModal(true)}
            className="px-4 py-2 bg-emerald-500 text-slate-950 text-xs font-extrabold rounded-lg hover:bg-emerald-400 transition flex items-center gap-1.5 shadow-[0_0_15px_rgba(16,185,129,0.3)]"
          >
            <Plus className="w-4 h-4 text-slate-950" />
            <span>TẠO CÔNG VIỆC MỚI</span>
          </button>
        </div>
      </div>

      {/* SLA Risk Notices */}
      <AnimatePresence>
        {aiFeedback && (
          <motion.div 
            initial={{ opacity: 0, y: -10 }} 
            animate={{ opacity: 1, y: 0 }} 
            exit={{ opacity: 0, y: -10 }}
            className="p-3.5 bg-indigo-950/40 border border-indigo-500/30 rounded-xl text-xs text-indigo-300 flex items-center justify-between"
          >
            <div className="flex items-center gap-2">
              <Zap className="w-4 h-4 text-indigo-400 animate-bounce" />
              <span>{aiFeedback}</span>
            </div>
            <button onClick={() => setAiFeedback(null)} className="text-indigo-400 hover:text-white">✕</button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* SLA Performance & points dashboard */}
      {(() => {
        const totalOverdue = tasks.filter(t => t.status !== 'done' && t.dueDate && t.dueDate < todayStr).length;
        const totalCompleted = tasks.filter(t => t.status === 'done').length;
        const totalDoing = tasks.filter(t => t.status !== 'done').length;

        // Obtain detail reports of overdue/near overdue staff & tasks
        const overdueTaskDetails = tasks.filter(t => t.status !== 'done' && t.dueDate && t.dueDate < todayStr);
        const nearOverdueTaskDetails = tasks.filter(t => {
          const isOverdue = t.status !== 'done' && t.dueDate && t.dueDate < todayStr;
          const isNear = t.status !== 'done' && t.dueDate && t.dueDate >= todayStr && 
                         (new Date(t.dueDate).getTime() - new Date(todayStr).getTime()) <= 2 * 24 * 3600 * 1000;
          return isNear && !isOverdue;
        });

        return (
          <div className="bg-[#111726]/40 p-4 rounded-2xl border border-slate-800/80 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800/60 pb-3">
              <div className="flex items-center gap-2">
                <Award className="w-5 h-5 text-amber-400 animate-pulse" />
                <div>
                  <h3 className="text-xs font-bold font-mono tracking-wider text-slate-100 uppercase">Kiểm soát SLA Trễ hạn & Thống kê KPI Tín Dân</h3>
                  <p className="text-[10px] text-slate-400 font-light mt-0.5">Hệ thống tính điểm tự động: Task hoàn thành đúng hạn <span className="text-emerald-400 font-bold font-mono">+5đ</span>, trễ hạn bị phạt <span className="text-rose-450 font-bold font-mono">-5đ</span>.</p>
                </div>
              </div>
              
              <div className="flex items-center gap-1.5 bg-slate-950/60 px-3 py-1.5 rounded-lg border border-slate-800 text-[10px] font-mono text-slate-400 self-start sm:self-center">
                <ShieldAlert className="w-3.5 h-3.5 text-rose-500 animate-pulse" />
                <span>Khóa sửa điểm chốt:</span>
                <span className="font-extrabold text-rose-400 uppercase">Chỉ Sếp Tuấn Anh (Admin)</span>
              </div>
            </div>

            {/* Interactive Stats Cards Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
              <button 
                onClick={() => setStatusTimeFilter(statusTimeFilter === 'overdue' ? 'all' : 'overdue')}
                className={`text-left p-3.5 rounded-xl border transition-all ${
                  statusTimeFilter === 'overdue' 
                    ? 'bg-rose-500/10 border-rose-500 ring-1 ring-rose-500/30' 
                    : 'bg-slate-950/40 border-slate-850 hover:bg-slate-950 hover:border-slate-800'
                }`}
              >
                <div className="flex justify-between items-center text-slate-500">
                  <span className="text-[10px] font-mono font-bold tracking-wider uppercase">Tổng Task Trễ Hạn</span>
                  <span className="text-[9px] font-mono font-bold bg-rose-500/20 text-rose-400 px-1.5 rounded">-5đ/task</span>
                </div>
                <div className="flex items-baseline gap-2 mt-2">
                  <span className="text-xl font-black font-display text-rose-400">{totalOverdue}</span>
                  <span className="text-[10px] text-slate-500 font-mono">công việc</span>
                </div>
                <span className="text-[9px] text-indigo-400 font-mono block mt-2 hover:underline">
                  {statusTimeFilter === 'overdue' ? '✕ Bỏ lọc' : '→ Click để lọc'}
                </span>
              </button>

              <button 
                onClick={() => setStatusTimeFilter(statusTimeFilter === 'near_overdue' ? 'all' : 'near_overdue')}
                className={`text-left p-3.5 rounded-xl border transition-all ${
                  statusTimeFilter === 'near_overdue' 
                    ? 'bg-amber-500/10 border-amber-500 ring-1 ring-amber-500/30' 
                    : 'bg-slate-950/40 border-slate-850 hover:bg-slate-950 hover:border-slate-800'
                }`}
              >
                <div className="flex justify-between items-center text-slate-500">
                  <span className="text-[10px] font-mono font-bold tracking-wider uppercase">Sắp Trễ Hạn (&le;2 ngày)</span>
                  <span className="text-[9px] font-mono font-bold bg-amber-500/20 text-amber-400 px-1.5 rounded">⚠️ Cảnh báo</span>
                </div>
                <div className="flex items-baseline gap-2 mt-2">
                  <span className="text-xl font-black font-display text-amber-400">{nearOverdueTaskDetails.length}</span>
                  <span className="text-[10px] text-slate-500 font-mono">công việc</span>
                </div>
                <span className="text-[9px] text-indigo-400 font-mono block mt-2 hover:underline">
                  {statusTimeFilter === 'near_overdue' ? '✕ Bỏ lọc' : '→ Click để lọc'}
                </span>
              </button>

              <button 
                onClick={() => setStatusTimeFilter(statusTimeFilter === 'doing' ? 'all' : 'doing')}
                className={`text-left p-3.5 rounded-xl border transition-all ${
                  statusTimeFilter === 'doing' 
                    ? 'bg-blue-500/10 border-blue-500 ring-1 ring-blue-500/30' 
                    : 'bg-slate-950/40 border-slate-850 hover:bg-slate-950 hover:border-slate-800'
                }`}
              >
                <div className="flex justify-between items-center text-slate-500">
                  <span className="text-[10px] font-mono font-bold tracking-wider uppercase">Đang Làm / Đang Chạy</span>
                  <span className="text-[9px] font-mono font-bold bg-blue-500/20 text-blue-400 px-1.5 rounded">Đang chạy</span>
                </div>
                <div className="flex items-baseline gap-2 mt-2">
                  <span className="text-xl font-black font-display text-blue-400">{totalDoing}</span>
                  <span className="text-[10px] text-slate-500 font-mono">công việc</span>
                </div>
                <span className="text-[9px] text-indigo-400 font-mono block mt-2 hover:underline">
                  {statusTimeFilter === 'doing' ? '✕ Bỏ lọc' : '→ Click để lọc'}
                </span>
              </button>

              <button 
                onClick={() => setStatusTimeFilter(statusTimeFilter === 'done' ? 'all' : 'done')}
                className={`text-left p-3.5 rounded-xl border transition-all ${
                  statusTimeFilter === 'done' 
                    ? 'bg-emerald-500/10 border-emerald-500 ring-1 ring-emerald-500/30' 
                    : 'bg-slate-950/40 border-slate-850 hover:bg-slate-950 hover:border-slate-800'
                }`}
              >
                <div className="flex justify-between items-center text-slate-500">
                  <span className="text-[10px] font-mono font-bold tracking-wider uppercase">Tổng Task Done</span>
                  <span className="text-[9px] font-mono font-bold bg-emerald-500/20 text-emerald-400 px-1.5 rounded">+5đ/task</span>
                </div>
                <div className="flex items-baseline gap-2 mt-2">
                  <span className="text-xl font-black font-display text-emerald-400">{totalCompleted}</span>
                  <span className="text-[10px] text-slate-500 font-mono">hoàn thành</span>
                </div>
                <span className="text-[9px] text-indigo-400 font-mono block mt-2 hover:underline">
                  {statusTimeFilter === 'done' ? '✕ Bỏ lọc' : '→ Click để lọc'}
                </span>
              </button>
            </div>

            {/* Inner detailed lists: Overdue / Near Overdue and Leaderboard */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 border-t border-slate-800/40 pt-4">
              
              {/* Overdue Staff report */}
              <div className="bg-slate-950/30 p-3 rounded-xl border border-slate-850 space-y-2">
                <div className="flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-rose-500 animate-ping"></span>
                  <h4 className="text-[10px] font-mono font-extrabold text-rose-400 uppercase tracking-wider">Nhân Viên Đang Trễ Hạn</h4>
                </div>
                
                <div className="space-y-1.5 max-h-[160px] overflow-y-auto pr-1">
                  {overdueTaskDetails.length > 0 ? (
                    overdueTaskDetails.map(task => {
                      const staff = users.find(u => u.name === task.assignedTo || u.id === task.assignedTo);
                      return (
                        <div key={task.id} className="bg-slate-950/60 p-2 rounded-lg border border-slate-900/60 flex justify-between items-center text-[11px] hover:border-rose-500/45 transition">
                          <div className="flex items-center gap-2">
                            {staff?.avatar && <img src={staff.avatar} alt={staff.name} className="w-5 h-5 rounded-full object-cover shrink-0" />}
                            <div>
                              <span className="font-bold text-slate-200 block">{task.assignedTo}</span>
                              <span className="text-[9px] text-slate-500 block truncate max-w-[120px]">{task.title}</span>
                            </div>
                          </div>
                          <div className="text-right shrink-0">
                            <span className="text-rose-400 font-bold block">{task.dueDate}</span>
                            <span className="text-[8px] font-mono text-slate-500 block">Trễ hạn (-5đ)</span>
                          </div>
                        </div>
                      );
                    })
                  ) : (
                    <p className="text-[10px] text-slate-500 italic py-2">Không có nhân viên thực thi nào bị trễ hạn. Sếp đánh giá tốt! 🌟</p>
                  )}
                </div>
              </div>

              {/* Near Overdue Staff report */}
              <div className="bg-slate-950/30 p-3 rounded-xl border border-slate-850 space-y-2">
                <div className="flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-amber-500"></span>
                  <h4 className="text-[10px] font-mono font-extrabold text-amber-400 uppercase tracking-wider">Nhân Viên Sắp Trễ</h4>
                </div>
                
                <div className="space-y-1.5 max-h-[160px] overflow-y-auto pr-1">
                  {nearOverdueTaskDetails.length > 0 ? (
                    nearOverdueTaskDetails.map(task => {
                      const staff = users.find(u => u.name === task.assignedTo || u.id === task.assignedTo);
                      return (
                        <div key={task.id} className="bg-slate-950/60 p-2 rounded-lg border border-slate-900/60 flex justify-between items-center text-[11px] hover:border-amber-500/40 transition">
                          <div className="flex items-center gap-2">
                            {staff?.avatar && <img src={staff.avatar} alt={staff.name} className="w-5 h-5 rounded-full object-cover shrink-0" />}
                            <div>
                              <span className="font-bold text-slate-200 block">{task.assignedTo}</span>
                              <span className="text-[9px] text-slate-500 block truncate max-w-[120px]">{task.title}</span>
                            </div>
                          </div>
                          <div className="text-right shrink-0">
                            <span className="text-amber-400 font-bold block">{task.dueDate}</span>
                            <span className="text-[8px] font-mono text-slate-500 block">⏳ Cần đẩy nhanh</span>
                          </div>
                        </div>
                      );
                    })
                  ) : (
                    <p className="text-[10px] text-slate-500 italic py-2 font-light">Không có tác vụ nào cận kề hạn chót.</p>
                  )}
                </div>
              </div>

              {/* Leaderboard points table */}
              <div className="bg-slate-950/30 p-3 rounded-xl border border-slate-850 space-y-2">
                <div className="flex items-center justify-between">
                  <h4 className="text-[10px] font-mono font-extrabold text-emerald-400 uppercase tracking-wider">Bảng Điểm Thưởng / Phạt Kỷ Luật</h4>
                  <span className="text-[8px] bg-emerald-500/20 text-emerald-400 px-1.5 py-0.5 rounded font-mono">Tính điểm live</span>
                </div>
                
                <div className="space-y-1.5 max-h-[160px] overflow-y-auto pr-1">
                  {Array.from(new Map(users.map(u => [u.id, u])).values()).map(user => {
                    const staffTasks = tasks.filter(t => t.assignedTo === user.name || t.assignedTo === user.id);
                    const doneCnt = staffTasks.filter(t => t.status === 'done').length;
                    const overdueCnt = staffTasks.filter(t => t.status !== 'done' && t.dueDate && t.dueDate < todayStr).length;
                    
                    // Score = Done * 5 - Overdue * 5
                    const performanceScore = (doneCnt * 5) - (overdueCnt * 5);
                    const colorStyle = performanceScore > 0 ? 'text-emerald-400' : performanceScore < 0 ? 'text-rose-450 font-extrabold' : 'text-slate-400';

                    return (
                      <div key={user.id} className="bg-slate-950/60 p-2 rounded-lg border border-slate-900/60 flex justify-between items-center text-[11px] hover:border-slate-800 transition">
                        <div className="flex items-center gap-2">
                          {user.avatar && <img src={user.avatar} alt={user.name} className="w-5 h-5 rounded-full object-cover shrink-0" />}
                          <div>
                            <span className="font-bold text-slate-200 block">{user.name}</span>
                            <span className="text-[8px] text-slate-500 block font-mono">Xong: {doneCnt} | Trễ: {overdueCnt}</span>
                          </div>
                        </div>
                        <div className="text-right shrink-0">
                          <span className={`text-[11px] font-black font-mono block ${colorStyle}`}>
                            {performanceScore > 0 ? `+${performanceScore}` : performanceScore}đ
                          </span>
                          <span className="text-[7px] text-slate-500 font-mono block uppercase">Tổng điểm</span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

            </div>
          </div>
        );
      })()}

      {/* 2. Unified Navigation and Filtering Row */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-4 items-center">
        <div className="md:col-span-6 flex flex-wrap bg-slate-950/80 p-1.5 rounded-xl border border-slate-800/80 gap-1">
          {[
            { id: 'kanban', label: 'Bảng Kanban', icon: Kanban },
            { id: 'list', label: 'Danh Sách', icon: ListIcon },
            { id: 'calendar', label: 'Lịch Biểu', icon: CalendarIcon },
            { id: 'timeline', label: 'Timeline (Gantt)', icon: GitBranch },
            { id: 'workload', label: 'Khối Lượng Team', icon: Users },
            { id: 'aipriority', label: 'Ưu Tiên AI', icon: Sparkles }
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setViewMode(tab.id as any)}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-bold transition-all ${
                viewMode === tab.id 
                  ? 'bg-slate-800 text-emerald-400 border border-slate-700' 
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <tab.icon className="w-3.5 h-3.5" />
              <span>{tab.label}</span>
            </button>
          ))}
        </div>

        {/* Filters */}
        <div className="md:col-span-6 flex flex-wrap sm:flex-nowrap gap-2">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Tìm việc, người đảm nhận..."
              className="w-full bg-[#111726]/80 text-slate-200 pl-9 pr-3 py-2 text-xs border border-slate-800 rounded-xl focus:border-emerald-500 focus:outline-none focus:ring-1 focus:ring-emerald-500"
            />
          </div>

          <select
            value={statusTimeFilter}
            onChange={(e) => setStatusTimeFilter(e.target.value as any)}
            className="bg-[#111726]/80 text-slate-300 border border-slate-800 rounded-xl px-3 py-1.5 text-xs focus:outline-none cursor-pointer"
          >
            <option value="all">Mọi Hạn & Trạng Thái</option>
            <option value="done">Lọc: Đã xong (+5đ)</option>
            <option value="doing">Lọc: Đang làm / chạy</option>
            <option value="overdue">Lọc: Bị trễ hạn (-5đ) ⚠️</option>
            <option value="near_overdue">Lọc: Sắp trễ (&le; 2 ngày) ⏳</option>
          </select>

          <select
            value={selectedDeptFilter}
            onChange={(e) => setSelectedDeptFilter(e.target.value)}
            className="bg-[#111726]/80 text-slate-300 border border-slate-800 rounded-xl px-3 py-1.5 text-xs focus:outline-none cursor-pointer"
          >
            <option value="All">Tất cả Phòng ban</option>
            <option value="CRO Tăng Trưởng">CRO Tăng Trưởng</option>
            <option value="Phát Triển Kỹ Thuật">Phát Triển Kỹ Thuật</option>
            <option value="Tối Ưu Phễu">Tối Ưu Phễu</option>
            <option value="Dịch Vụ Khách Hàng">Dịch Vụ Khách Hàng</option>
          </select>
        </div>
      </div>

      {/* 3. Main Views Execution Area */}
      <AnimatePresence mode="wait">
        
        {/* VIEW: KANBAN BOARD */}
        {viewMode === 'kanban' && (
          <motion.div 
            initial={{ opacity: 0 }} 
            animate={{ opacity: 1 }} 
            exit={{ opacity: 0 }}
            className="grid grid-cols-1 md:grid-cols-4 gap-4"
          >
            {['todo', 'in_progress', 'backlog', 'done'].map((status) => {
              const columnsTasks = filteredTasks.filter(t => t.status === status);
              const titleMap: Record<string, string> = {
                todo: 'CHỜ TRIỂN KHAI',
                in_progress: 'ĐANG CHẠY',
                backlog: 'TỒN ĐỌNG (BACKLOG)',
                done: 'ĐÃ HOÀN THÀNH'
              };
              const colorMap: Record<string, string> = {
                todo: 'bg-yellow-400',
                in_progress: 'bg-blue-400',
                backlog: 'bg-rose-500',
                done: 'bg-emerald-400'
              };

              return (
                <div key={status} className="bg-[#101524] rounded-2xl p-4 border border-slate-800/80 min-h-[480px] flex flex-col">
                  {/* Col header */}
                  <div className="flex items-center justify-between pb-3.5 border-b border-slate-800 mb-4">
                    <div className="flex items-center gap-2">
                      <span className={`w-2.5 h-2.5 rounded-full ${colorMap[status]}`} />
                      <span className="text-xs font-extrabold uppercase tracking-wider text-slate-200">
                        {titleMap[status]}
                      </span>
                    </div>
                    <span className="text-[10px] bg-slate-800 px-2 py-0.5 rounded-full font-mono text-slate-400 font-bold">
                      {columnsTasks.length}
                    </span>
                  </div>

                  {/* Task Stack cards */}
                  <div className="flex-1 space-y-3.5 overflow-y-auto pr-1">
                    {columnsTasks.length === 0 ? (
                      <div className="py-12 text-center text-slate-500 border border-dashed border-slate-800/60 rounded-xl text-xs">
                        Trống
                      </div>
                    ) : (
                      columnsTasks.map(t => {
                        const isBlocked = checkDependencyBlocked(t);
                        return (
                          <div
                            key={t.id}
                            onClick={() => setSelectedTask(t)}
                            className={`p-4 rounded-xl border bg-slate-900/60 hover:bg-slate-900 cursor-pointer transition-all duration-300 space-y-3 ${
                              isBlocked ? 'border-orange-500/40 relative' : 'border-slate-800 hover:border-emerald-500/50'
                            }`}
                          >
                            <div className="flex justify-between items-start gap-2">
                              <span className="text-[9px] px-2 py-0.5 bg-slate-800 border border-slate-700/60 rounded uppercase tracking-wider">
                                {t.department}
                              </span>
                              
                              <div className="flex items-center gap-1.5">
                                {t.AI_score !== undefined && (
                                  <span className="text-[9px] bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 px-1.5 py-0.5 rounded font-mono font-bold">
                                    AI: {t.AI_score}đ
                                  </span>
                                )}
                                <span className={`text-[9px] font-extrabold uppercase px-1.5 py-0.5 rounded font-mono ${
                                  t.priority === 'critical' ? 'bg-red-500/20 text-red-400 border border-red-500/30' :
                                  t.priority === 'high' ? 'bg-amber-500/10 text-amber-400' : 'bg-slate-800 text-slate-400'
                                }`}>
                                  {t.priority}
                                </span>
                              </div>
                            </div>

                            {/* Blocking Dependency Notice */}
                            {isBlocked && (
                              <div className="flex items-center gap-1 bg-orange-950/30 border border-orange-500/30 p-1.5 rounded-lg text-[9px] text-orange-400">
                                <AlertTriangle className="w-3.5  h-3.5 text-orange-500 animate-pulse shrink-0" />
                                <span>Bị chặn bởi nhiệm vụ tiên quyết!</span>
                              </div>
                            )}

                            <div>
                              <h4 className="text-xs font-extrabold text-slate-100 line-clamp-1 hover:text-emerald-400 transition">{t.title}</h4>
                              <p className="text-[11px] text-slate-400 line-clamp-2 mt-1">{t.description}</p>
                            </div>

                            {/* Subtasks status meter */}
                            {t.subtasks && t.subtasks.length > 0 && (
                              <div className="space-y-1">
                                <div className="flex justify-between text-[9px] text-slate-500 font-mono">
                                  <span>Checklist:</span>
                                  <span>{t.subtasks.filter(s => s.done).length}/{t.subtasks.length}</span>
                                </div>
                                <div className="w-full h-1 bg-slate-850 rounded-full overflow-hidden">
                                  <div 
                                    className="h-full bg-emerald-400 transition-all duration-300" 
                                    style={{ width: `${(t.subtasks.filter(s => s.done).length / t.subtasks.length) * 100}%` }} 
                                  />
                                </div>
                              </div>
                            )}

                            {/* Card Footer info */}
                            <div className="flex justify-between items-center pt-2.5 border-t border-slate-800 text-[10px] font-mono text-slate-400">
                              <span className="flex items-center gap-1">
                                <Clock className="w-3 h-3 text-emerald-400" />
                                <span>{t.dueDate}</span>
                              </span>
                              <span className="bg-slate-800 text-slate-300 px-1.5 py-0.5 rounded font-bold">
                                {t.assignedTo.split(' ')[0]}
                              </span>
                            </div>
                          </div>
                        );
                      })
                    )}
                  </div>
                </div>
              );
            })}
          </motion.div>
        )}

        {/* VIEW: DETAILED LIST VIEW */}
        {viewMode === 'list' && (
          <motion.div 
            initial={{ opacity: 0 }} 
            animate={{ opacity: 1 }} 
            exit={{ opacity: 0 }}
            className="overflow-x-auto bg-[#101524] rounded-2xl border border-slate-800/80"
          >
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="bg-slate-950/60 border-b border-slate-800 text-slate-400 uppercase tracking-wider font-mono">
                  <th className="p-4">Tác Vụ</th>
                  <th className="p-4">Phòng Ban</th>
                  <th className="p-4">Giao Cho</th>
                  <th className="p-4">Thời Hạn</th>
                  <th className="p-4">Khối Lượng</th>
                  <th className="p-4">SLA Level</th>
                  <th className="p-4 font-mono text-right">Trạng Thái</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800">
                {filteredTasks.map(t => (
                  <tr 
                    key={t.id} 
                    onClick={() => setSelectedTask(t)}
                    className="hover:bg-slate-900/40 cursor-pointer transition"
                  >
                    <td className="p-4">
                      <div className="font-extrabold text-slate-100">{t.title}</div>
                      <div className="text-[10px] text-slate-500 mt-0.5 line-clamp-1">{t.description}</div>
                    </td>
                    <td className="p-4 font-mono text-xs text-slate-300">{t.department}</td>
                    <td className="p-4">
                      <span className="px-2.5 py-1 bg-slate-800 text-slate-300 rounded font-bold text-[10px]">
                        {t.assignedTo}
                      </span>
                    </td>
                    <td className="p-4 font-mono text-xs text-indigo-300">{t.dueDate}</td>
                    <td className="p-4 font-mono text-xs text-slate-400">{t.estimated_hours || 8} giờ</td>
                    <td className="p-4">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                        t.SLA_level === 'critical' ? 'bg-red-500/10 text-red-400' : 'bg-slate-800/80 text-slate-400'
                      }`}>
                        {t.SLA_level || 'Normal'}
                      </span>
                    </td>
                    <td className="p-4 text-right">
                      <span className={`px-2 py-1 rounded text-[10px] font-bold uppercase ${
                        t.status === 'done' ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' : 'bg-amber-500/10 text-amber-400'
                      }`}>
                        {t.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </motion.div>
        )}

        {/* VIEW: FULL CALENDAR BIỂU */}
        {viewMode === 'calendar' && (
          <motion.div 
            initial={{ opacity: 0 }} 
            animate={{ opacity: 1 }} 
            exit={{ opacity: 0 }}
            className="bg-[#101524] rounded-2xl p-5 border border-slate-800/80 space-y-4"
          >
            <div className="flex justify-between items-center border-b border-slate-800 pb-3">
              <span className="font-mono text-xs font-bold text-slate-400">GIÁM SÁT TIẾN ĐỘ THÁNG 6 - 2026</span>
              <span className="text-[10px] bg-emerald-500/20 text-emerald-300 px-2.5 py-1 rounded-full font-bold">Chế độ đồng bộ thời gian thực</span>
            </div>

            <div className="grid grid-cols-7 gap-2.5">
              {['T2', 'T3', 'T4', 'T5', 'T6', 'T7', 'CN'].map(d => (
                <div key={d} className="p-2 text-center bg-slate-950/60 rounded text-slate-500 text-xs font-bold font-mono">{d}</div>
              ))}
              
              {/* Build calendar cells (days 10th to 23th of June, 2026) */}
              {Array.from({ length: 14 }).map((_, i) => {
                const dayNum = i + 10;
                const formattedDate = `2026-06-${dayNum}`;
                const dailyTasks = filteredTasks.filter(t => t.dueDate === formattedDate);

                return (
                  <div key={i} className="min-h-[110px] bg-slate-900/40 border border-slate-800/60 rounded-xl p-2.5 space-y-1.5 flex flex-col justify-between">
                    <span className="font-mono text-xs font-bold text-slate-500">{dayNum} Th6</span>
                    
                    <div className="space-y-1.5 flex-1 overflow-y-auto">
                      {dailyTasks.map(t => (
                        <div 
                          key={t.id} 
                          onClick={() => setSelectedTask(t)}
                          className="p-1 px-1.5 bg-indigo-500/10 border border-indigo-500/20 rounded text-[9px] line-clamp-1 font-bold text-slate-300 hover:border-emerald-400 transition cursor-pointer"
                        >
                          {t.title}
                        </div>
                      ))}
                    </div>
                  </div>
                );
              })}
            </div>
          </motion.div>
        )}

        {/* VIEW: TIMELINE (GANTT WITH DEPENDENCIES CONNECTED) */}
        {viewMode === 'timeline' && (
          <motion.div 
            initial={{ opacity: 0 }} 
            animate={{ opacity: 1 }} 
            exit={{ opacity: 0 }}
            className="bg-[#101524] rounded-2xl p-5 border border-slate-800/80 space-y-6"
          >
            <div className="flex justify-between items-center">
              <div>
                <h4 className="text-xs font-extrabold uppercase tracking-widest text-slate-300">Biểu Đồ Gantt & Chuỗi Phụ Thuộc (Dependency Graph)</h4>
                <p className="text-[10px] text-slate-500 mt-0.5">Xác định các đầu việc then chốt, chuỗi chuyển tiếp không vỡ nứt</p>
              </div>
              <div className="text-[10px] bg-amber-500/10 border border-amber-500/20 px-2 py-1 rounded text-amber-400 flex items-center gap-1">
                <AlertTriangle className="w-3.5 h-3.5" />
                <span>Auto Deadlock Warning Active</span>
              </div>
            </div>

            <div className="space-y-4">
              {filteredTasks.map(t => {
                const depTasks = t.dependencies?.map(depId => tasks.find(dep => dep.id === depId)).filter(Boolean);
                
                return (
                  <div key={t.id} className="grid grid-cols-12 items-center gap-4 bg-[#111726]/40 p-3 rounded-xl border border-slate-800">
                    <div className="col-span-3">
                      <span className="font-extrabold text-xs block text-slate-200">{t.title}</span>
                      <span className="text-[10px] text-slate-400 mt-0.5">Thời hạn: {t.dueDate}</span>
                    </div>

                    {/* Timeline bar map */}
                    <div className="col-span-6 relative h-6 bg-slate-950/60 rounded-full overflow-hidden border border-slate-850">
                      <div 
                        className={`absolute top-0 bottom-0 rounded-full transition-all duration-300 ${
                          t.status === 'done' ? 'bg-gradient-to-r from-emerald-500 to-teal-500 shadow-[0_0_10px_rgba(16,185,129,0.25)]' : 'bg-gradient-to-r from-blue-500 to-indigo-500'
                        }`}
                        style={{ left: t.status === 'done' ? '0%' : '15%', right: t.status === 'done' ? '0%' : '40%' }}
                      />
                      <span className="absolute inset-0 flex items-center justify-center text-[10px] font-mono font-bold text-white uppercase select-none">
                        {t.status === 'done' ? '100% Hoàn Thành' : 'Chờ unlock liên hoàn'}
                      </span>
                    </div>

                    {/* Dependency mapping */}
                    <div className="col-span-3 text-right">
                      {depTasks && depTasks.length > 0 ? (
                        depTasks.map(dep => (
                          <div key={dep?.id} className="inline-flex items-center gap-1 text-[10px] font-mono bg-yellow-500/10 border border-yellow-500/20 text-yellow-500 px-2 py-0.5 rounded-full">
                            <CornerDownRight className="w-3 h-3 text-yellow-500 shrink-0" />
                            <span>Chờ: {dep?.title.substring(0, 15)}...</span>
                          </div>
                        ))
                      ) : (
                        <span className="text-[10px] text-slate-500 italic">Đầu việc độc lập</span>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </motion.div>
        )}

        {/* VIEW: WORKLOAD BALANCE HEATMAP */}
        {viewMode === 'workload' && (
          <motion.div 
            initial={{ opacity: 0 }} 
            animate={{ opacity: 1 }} 
            exit={{ opacity: 0 }}
            className="space-y-6"
          >
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              
              {/* Heatmap capacity details */}
              <div className="lg:col-span-2 bg-[#101524] p-5 rounded-2xl border border-slate-800/80 space-y-4">
                <h4 className="text-xs font-extrabold uppercase tracking-wider text-slate-300">Biểu đồ Giờ Công và Mức Cân Bằng Toàn Team</h4>
                <div className="h-[220px]">
                  <ResponsiveContainer width="99%" height="100%" minWidth={100} minHeight={220}>
                    <BarChart data={getWorkloadChartData()}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#1d243b" />
                      <XAxis dataKey="name" stroke="#64748b" fontSize={10} />
                      <YAxis stroke="#64748b" fontSize={10} />
                      <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#1e293b' }} />
                      <Bar dataKey="Số giờ đã giao (Giờ)" fill="#10b981" radius={[4, 4, 0, 0]} />
                      <Bar dataKey="Hạn mức năng lực (Max)" fill="#312e81" radius={[4, 4, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>

              {/* Workload suggest card */}
              <div className="bg-[#101524] p-5 rounded-2xl border border-slate-800/80 space-y-4 flex flex-col justify-between">
                <div>
                  <h4 className="text-xs font-extrabold uppercase tracking-wider text-indigo-400">AI WORKFLOW BALANCER</h4>
                  <p className="text-[11px] text-slate-400 mt-1">
                    Hệ thống sẽ chạy thuật toán phân phối tải trọng CRO tự động nhằm tránh rủi ro kiệt quệ sức lao động hoặc thiếu hụt năng suất.
                  </p>
                </div>

                <div className="space-y-3 bg-[#111726]/40 p-4 rounded-xl border border-slate-800 text-xs">
                  <div className="font-bold text-slate-200">Trạng Thái AI Ghi Nhận:</div>
                  <ul className="space-y-2 text-slate-400 text-[11px] list-disc pl-4">
                    <li>Nguyễn Văn Đạt hiện dồn ứ {tasks.filter(t => t.assignedTo === '2' && t.status !== 'done').length} đầu việc.</li>
                    <li>Sếp Tuấn Anh và hệ thống Proxy đang vận hành tối ưu.</li>
                  </ul>
                </div>

                <button
                  onClick={runWorkflowAudit}
                  disabled={aiAnalyzing}
                  className="w-full py-2.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-extrabold text-xs rounded-xl shadow transition"
                >
                  {aiAnalyzing ? "ĐANG ĐO ĐẠC..." : "CHẠY AUDIT CÂN BẰNG TẢI TRỌNG"}
                </button>
              </div>

            </div>

            {/* AI Analyzer Audit Dashboard Panel */}
            {aiAnalysisResult && (
              <motion.div 
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="p-5 bg-indigo-950/20 border border-indigo-500/30 rounded-2xl space-y-4"
              >
                <div className="flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-indigo-400 animate-pulse" />
                  <span className="font-extrabold text-xs uppercase text-indigo-300">Kết quả phân tích từ Lê Thị Mỹ Duyên AI</span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                  <div className="space-y-2">
                    <span className="font-bold text-slate-300 block">⚠️ BOTTLENECKS PHÁT HIỆN:</span>
                    <ul className="space-y-1 text-slate-400 list-disc pl-4">
                      {aiAnalysisResult.bottlenecks?.map((b: string, idx: number) => (
                        <li key={idx}>{b}</li>
                      ))}
                    </ul>
                  </div>

                  <div className="space-y-2">
                    <span className="font-bold text-slate-300 block">⚡ KHUYẾN NGHỊ PHÂN CHIA LẠI:</span>
                    <div className="space-y-2">
                      {aiAnalysisResult.reassignments?.map((r: any, idx: number) => (
                        <div key={idx} className="p-2.5 bg-slate-950/40 border border-slate-800 rounded-lg">
                          <span className="text-[11px] block text-slate-300">Công việc <strong>{r.taskId}</strong>: chuyển từ <strong>{r.current}</strong> ➔ <strong>{r.suggested}</strong></span>
                          <span className="text-[9px] text-slate-500 mt-1 block">Lý do: {r.reason}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </motion.div>
            )}
          </motion.div>
        )}

        {/* VIEW: AI PRIORITY ORDER VIEWS */}
        {viewMode === 'aipriority' && (
          <motion.div 
            initial={{ opacity: 0 }} 
            animate={{ opacity: 1 }} 
            exit={{ opacity: 0 }}
            className="space-y-6"
          >
            <div className="p-5 bg-[#101524] rounded-2xl border border-slate-800/80 space-y-4">
              <div className="flex justify-between items-center">
                <div>
                  <h4 className="text-xs font-extrabold uppercase tracking-widest text-indigo-400">Smart Priority Ranking Engine</h4>
                  <p className="text-[11px] text-slate-500 mt-0.5">Xếp hạng mức mật độ rủi ro xử lý tự động của Tín Dân</p>
                </div>
                <button
                  onClick={recalculateAiScores}
                  className="px-3 py-1.5 bg-indigo-600/20 text-indigo-300 text-[10px] font-bold rounded-lg border border-indigo-500/20 hover:bg-indigo-600/30 transition shadow-sm"
                >
                  Refresh AI Ranking
                </button>
              </div>

              <div className="space-y-3">
                {[...filteredTasks].sort((a, b) => (b.AI_score || 0) - (a.AI_score || 0)).map((t, idx) => (
                  <div key={t.id} className="p-4 bg-slate-900/60 border border-slate-800/60 rounded-2xl flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                    <div className="flex gap-3.5 items-center">
                      <span className="w-6 h-6 bg-slate-800 text-[10px] font-mono font-bold text-slate-400 flex items-center justify-center rounded-full">
                        #{idx + 1}
                      </span>
                      <div>
                        <span className="text-xs font-extrabold text-slate-100">{t.title}</span>
                        <p className="text-[10px] text-slate-500 mt-0.5">SLA Level: {t.SLA_level} | KPI Weight: {t.KPI_weight}</p>
                      </div>
                    </div>

                    <div className="flex items-center gap-3 w-full sm:w-auto justify-between sm:justify-start">
                      <div className="text-right">
                        <span className="text-xs font-mono font-extrabold text-indigo-400 block">AI Score: {t.AI_score || 50}%</span>
                        <span className="text-[9px] text-rose-500 font-bold block bg-rose-500/10 px-1.5 rounded-full mt-0.5 text-center">Delay Risk</span>
                      </div>
                      <button
                        onClick={() => setSelectedTask(t)}
                        className="p-2 hover:bg-slate-800 rounded bg-slate-950 text-slate-400 hover:text-white"
                      >
                        ✕ Quick View
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </motion.div>
        )}

      </AnimatePresence>

      {/* 4. REALTIME TYPING INDICATOR SIMULATOR & AUTOMATION FEEDS */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        
        {/* Realtime collaboration commenting status */}
        <div className="p-4 bg-[#101524] rounded-2xl border border-slate-800 text-xs flex flex-col justify-between">
          <span className="font-mono font-extrabold text-slate-400 uppercase tracking-widest block text-[10px]">Realtime Collaboration Indicator</span>
          
          <div className="py-4 flex items-center gap-2.5">
            <div className="w-2.5 h-2.5 bg-blue-500 rounded-full animate-ping" />
            <span className="font-bold text-slate-400 text-[11px]">
              {typingIndicator || "Tất cả các tài khoản đang kết nối ổn định qua cổng Appwrite."}
            </span>
          </div>

          <p className="text-[9px] text-slate-600 font-mono">Bảng tuần hoàn số liệu được cập nhật từng giây từ Đại bản doanh 5001.</p>
        </div>

        {/* Automation script logs banner */}
        <div className="p-4 bg-[#101524] rounded-2xl border border-slate-800 text-xs flex flex-col justify-between space-y-2">
          <div className="flex justify-between items-center">
            <span className="font-mono font-extrabold text-slate-400 uppercase tracking-widest text-[10px]">Workflow Automation Trigger Controller</span>
            <span className="text-[9px] bg-emerald-500/10 text-emerald-400 px-1.5 rounded-full font-bold">Active</span>
          </div>

          <div className="space-y-1.5">
            {automationLogs.map((log, i) => (
              <div key={i} className="text-[10px] text-slate-400 font-mono flex items-center gap-1">
                <span className="text-emerald-500">✓</span>
                <span>{log}</span>
              </div>
            ))}
          </div>

          <span className="text-[9px] text-slate-600 font-mono">Quản trị viên có quyền cập nhật chuỗi tự động thông qua Zalo và Bypass.</span>
        </div>

      </div>

      {/* 5. GORGEOUS TASK DETAIL MODAL */}
      {selectedTask && (() => {
        const assigneeUser = users.find(u => u.id === selectedTask.assignedTo || u.name === selectedTask.assignedTo);
        const creatorUser = users.find(u => u.id === selectedTask.creator || u.name === selectedTask.creator || u.id === selectedTask.createdBy || u.name === selectedTask.createdBy);
        const followerUsers = (selectedTask.followers || []).map(fName => users.find(u => u.name === fName || u.id === fName)).filter(Boolean) as User[];

        return (
          <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-xs flex items-center justify-center p-4 z-50 overflow-y-auto">
            <div className="bg-[#0f1422] border border-slate-800 w-full max-w-2xl rounded-2xl shadow-2xl overflow-hidden block">
              
              {/* Modal Head Header */}
              <div className="bg-slate-900 p-5 border-b border-slate-800 flex justify-between items-center">
                <div>
                  <span className="text-[9px] font-mono font-extrabold text-indigo-400 uppercase tracking-widest block">
                    {isEditingTask ? "CHẾ ĐỘ CHỈNH SỬA TÁC VỤ • EDITING MODE" : "TASK FLOW CONSOLE"}
                  </span>
                  <h3 className="text-sm font-extrabold text-slate-100 font-display mt-1">
                    {isEditingTask ? "Đang Chỉnh Sửa Định Nghĩa Nhiệm Vụ" : selectedTask.title}
                  </h3>
                </div>
                <button
                  onClick={() => setSelectedTask(null)}
                  className="text-slate-500 hover:text-white"
                >
                  ✕
                </button>
              </div>

              {/* Modal Body */}
              <div className="p-6 space-y-6 max-h-[500px] overflow-y-auto">
                
                {isEditingTask ? (
                  /* EDITING FORM PORTAL */
                  <div className="space-y-4">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div className="sm:col-span-2">
                        <label className="block text-[10px] text-slate-400 mb-1 font-mono uppercase tracking-wider font-bold">Tên công việc *</label>
                        <input 
                          type="text" 
                          value={editTitle}
                          onChange={(e) => setEditTitle(e.target.value)}
                          className="w-full bg-[#111726]/60 border border-slate-800 rounded-lg py-2 px-3 text-slate-200 text-xs focus:border-indigo-500 focus:outline-none"
                        />
                      </div>

                      <div className="sm:col-span-2">
                        <label className="block text-[10px] text-slate-400 mb-1 font-mono uppercase tracking-wider font-bold">Mô tả tác vụ chi tiết</label>
                        <textarea 
                          value={editDesc}
                          onChange={(e) => setEditDesc(e.target.value)}
                          rows={3}
                          className="w-full bg-[#111726]/60 border border-slate-800 rounded-lg py-2 px-3 text-slate-200 text-xs focus:border-indigo-500 focus:outline-none"
                        />
                      </div>

                      <div>
                        <label className="block text-[10px] text-slate-400 mb-1 font-mono uppercase tracking-wider font-bold">Phòng ban</label>
                        <select 
                          value={editDept}
                          onChange={(e) => setEditDept(e.target.value)}
                          className="w-full bg-[#111726]/60 border border-slate-800 rounded-lg py-2 px-3 text-slate-200 text-xs focus:border-indigo-500 focus:outline-none"
                        >
                          <option value="Tăng Trưởng">Tăng Trưởng</option>
                          <option value="Phát Triển">Phát Triển</option>
                          <option value="Vận Hành">Vận Hành</option>
                          <option value="Thiết Kế">Thiết Kế</option>
                          <option value="Sản Phẩm">Sản Phẩm</option>
                        </select>
                      </div>

                      <div>
                        <label className="block text-[10px] text-slate-400 mb-1 font-mono uppercase tracking-wider font-bold">Độ ưu tiên (Priority)</label>
                        <select 
                          value={editPriority}
                          onChange={(e: any) => setEditPriority(e.target.value)}
                          className="w-full bg-[#111726]/60 border border-slate-800 rounded-lg py-2 px-3 text-slate-200 text-xs focus:border-indigo-500 focus:outline-none"
                        >
                          <option value="low">LOW</option>
                          <option value="medium">MEDIUM</option>
                          <option value="high">HIGH</option>
                          <option value="critical">CRITICAL</option>
                        </select>
                      </div>

                      <div>
                        <label className="block text-[10px] text-slate-400 mb-1 font-mono uppercase tracking-wider font-bold">Nhân viên phụ trách *</label>
                        <select 
                          value={editAssignee}
                          onChange={(e) => setEditAssignee(e.target.value)}
                          className="w-full bg-[#111726]/60 border border-slate-800 rounded-lg py-2 px-3 text-slate-200 text-xs focus:border-indigo-500 focus:outline-none"
                        >
                          {Array.from(new Map(users.map(u => [u.id, u])).values()).map(u => (
                            <option key={u.id} value={u.name}>{u.name} ({u.role})</option>
                          ))}
                        </select>
                      </div>

                      <div>
                        <label className="block text-[10px] text-slate-400 mb-1 font-mono uppercase tracking-wider font-bold">Người giao (Creator)</label>
                        <select 
                          value={editCreator}
                          onChange={(e) => setEditCreator(e.target.value)}
                          className="w-full bg-[#111726]/60 border border-slate-800 rounded-lg py-2 px-3 text-slate-200 text-xs focus:border-indigo-500 focus:outline-none"
                        >
                          {Array.from(new Map(users.map(u => [u.id, u])).values()).map(u => (
                            <option key={u.id} value={u.name}>{u.name}</option>
                          ))}
                        </select>
                      </div>

                      <div>
                        <label className="block text-[10px] text-slate-400 mb-1 font-mono uppercase tracking-wider font-bold">Ngày giao việc (Start Date)</label>
                        <input 
                          type="date" 
                          value={editStartDate}
                          onChange={(e) => setEditStartDate(e.target.value)}
                          className="w-full bg-[#111726]/60 border border-slate-800 rounded-lg py-2 px-3 text-slate-200 text-xs font-mono focus:border-indigo-500 focus:outline-none"
                        />
                      </div>

                      <div>
                        <label className="block text-[10px] text-slate-400 mb-1 font-mono uppercase tracking-wider font-bold">Hạn hoàn thành (Due Date)</label>
                        <input 
                          type="date" 
                          value={editDueDate}
                          onChange={(e) => setEditDueDate(e.target.value)}
                          className="w-full bg-[#111726]/60 border border-slate-800 rounded-lg py-2 px-3 text-slate-200 text-xs font-mono focus:border-indigo-500 focus:outline-none"
                        />
                      </div>

                      <div>
                        <label className="block text-[10px] text-slate-400 mb-1 font-mono uppercase tracking-wider font-bold">Thời lượng dự toán (Giờ)</label>
                        <input 
                          type="number" 
                          value={editEstHours}
                          onChange={(e) => setEditEstHours(Number(e.target.value))}
                          className="w-full bg-[#111726]/60 border border-slate-800 rounded-lg py-2 px-3 text-slate-200 text-xs font-mono focus:border-indigo-500 focus:outline-none"
                        />
                      </div>

                      <div>
                        <label className="block text-[10px] text-slate-400 mb-1 font-mono uppercase tracking-wider font-bold">
                          KPI Weight (điểm) 
                          {currentUser?.id !== '1' && <span className="text-rose-500 font-bold ml-1">(Chỉ Sếp sửa)</span>}
                        </label>
                        <input 
                          type="number" 
                          value={editKpiWeight}
                          onChange={(e) => setEditKpiWeight(Number(e.target.value))}
                          disabled={currentUser?.id !== '1'}
                          className="w-full bg-[#111726]/60 border border-slate-800 rounded-lg py-2 px-3 text-slate-200 text-xs font-mono focus:border-indigo-500 focus:outline-none disabled:opacity-50 disabled:cursor-not-allowed"
                        />
                      </div>

                      <div>
                        <label className="block text-[10px] text-slate-400 mb-1 font-mono uppercase tracking-wider font-bold">SLA Level</label>
                        <select 
                          value={editSlaLevel}
                          onChange={(e: any) => setEditSlaLevel(e.target.value)}
                          className="w-full bg-[#111726]/60 border border-slate-800 rounded-lg py-2 px-3 text-slate-200 text-xs focus:border-indigo-500 focus:outline-none"
                        >
                          <option value="low">LOW</option>
                          <option value="medium">MEDIUM</option>
                          <option value="high">HIGH</option>
                          <option value="critical">CRITICAL</option>
                        </select>
                      </div>

                      <div className="sm:col-span-2">
                        <label className="block text-[10px] text-slate-400 mb-1 font-mono uppercase tracking-wider font-bold">Nhân Viên Liên Quan / Theo Dõi</label>
                        <div className="p-3 bg-slate-950/60 border border-slate-800 rounded-xl max-h-[140px] overflow-y-auto space-y-2">
                          {Array.from(new Map(users.map(u => [u.id, u])).values()).map(u => {
                            const isSelected = editFollowers.includes(u.name) || editFollowers.includes(u.id);
                            return (
                              <label key={u.id} className="flex items-center gap-2.5 cursor-pointer text-xs select-none">
                                <input 
                                  type="checkbox" 
                                  checked={isSelected}
                                  onChange={() => {
                                    if (isSelected) {
                                      setEditFollowers(editFollowers.filter(f => f !== u.name && f !== u.id));
                                    } else {
                                      setEditFollowers([...editFollowers, u.name]);
                                    }
                                  }}
                                  className="rounded border-slate-700 text-emerald-500 bg-slate-950 focus:ring-0 w-3.5 h-3.5"
                                />
                                {u.avatar && <img src={u.avatar} alt={u.name} className="w-5 h-5 rounded-full object-cover" />}
                                <span className="text-slate-300 font-medium">{u.name} - <span className="text-slate-500 font-mono text-[10px]">{u.role}</span></span>
                              </label>
                            );
                          })}
                        </div>
                      </div>
                    </div>
                  </div>
                ) : (
                  /* SPECTACULAR INFORMATION DISPLAY PORTAL */
                  <>
                    {/* Multi-Column Key Parameters Card */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 bg-[#111726]/40 p-5 rounded-2xl border border-slate-800/80">
                      
                      {/* Left Block: Personnel Coordination & Context */}
                      <div className="space-y-4">
                        <div>
                          <span className="text-slate-500 text-[10px] uppercase font-mono font-bold block mb-1.5 tracking-wider">Nhân viên phụ trách (Assignee)</span>
                          {assigneeUser ? (
                            <div className="flex items-center gap-3 bg-slate-950/60 p-2.5 rounded-xl border border-slate-850">
                              {assigneeUser.avatar && (
                                <img 
                                  src={assigneeUser.avatar} 
                                  alt={assigneeUser.name} 
                                  referrerPolicy="no-referrer"
                                  className="w-9 h-9 rounded-xl object-cover border border-slate-800 shrink-0" 
                                />
                              )}
                              <div>
                                <span className="text-xs font-extrabold text-slate-100 block">{assigneeUser.name}</span>
                                <span className="text-[10px] text-slate-500 font-mono block">{assigneeUser.role || 'Nhân sự thực thi'}</span>
                              </div>
                            </div>
                          ) : (
                            <div className="flex items-center gap-2.5 bg-slate-950/60 p-2.5 rounded-xl border border-slate-850">
                              <span className="text-xs font-bold text-slate-400 italic block">{selectedTask.assignedTo || 'Chưa phân công'}</span>
                            </div>
                          )}
                        </div>

                        <div>
                          <span className="text-slate-500 text-[10px] uppercase font-mono font-bold block mb-1.5 tracking-wider">Người giao nhiệm vụ (Creator)</span>
                          {creatorUser ? (
                            <div className="flex items-center gap-2.5 bg-slate-950/20 p-2 rounded-xl border border-slate-900/60">
                              {creatorUser.avatar && (
                                <img 
                                  src={creatorUser.avatar} 
                                  alt={creatorUser.name} 
                                  referrerPolicy="no-referrer"
                                  className="w-6 h-6 rounded-lg object-cover shrink-0" 
                                />
                              )}
                              <span className="text-xs text-slate-300 font-semibold">{creatorUser.name}</span>
                            </div>
                          ) : (
                            <div className="flex items-center gap-2 bg-slate-950/20 p-2 rounded-xl border border-slate-900/60 font-medium text-xs text-slate-350">
                              <span>{selectedTask.creator || selectedTask.createdBy || 'Trần Tuấn Anh (Sếp)'}</span>
                            </div>
                          )}
                        </div>

                        <div>
                          <span className="text-slate-500 text-[10px] uppercase font-mono font-bold block mb-1.5 tracking-wider">Nhân viên liên quan (Related Personnel / Followers)</span>
                          <div className="flex flex-wrap gap-2">
                            {followerUsers.length > 0 ? (
                              followerUsers.map(fol => (
                                <div key={fol.id} className="flex items-center gap-2 bg-slate-950/30 p-1.5 px-2.5 rounded-lg border border-slate-850/60">
                                  {fol.avatar && <img src={fol.avatar} alt={fol.name} className="w-5 h-5 rounded-full object-cover shrink-0" />}
                                  <span className="text-[10px] font-medium text-slate-300">{fol.name.split(' ')[0]}</span>
                                </div>
                              ))
                            ) : (
                              <span className="text-[10px] text-slate-500 italic block font-mono">Không có nhân sự liên đới</span>
                            )}
                          </div>
                        </div>
                      </div>

                      {/* Right Block: Milestones, KPI weights & Timeline */}
                      <div className="space-y-4 border-t md:border-t-0 md:border-l border-slate-800/60 pt-4 md:pt-0 md:pl-4">
                        <div>
                          <span className="text-slate-500 text-[10px] uppercase font-mono font-bold block mb-1.5 tracking-wider">Chu kỳ & Tiến độ triển khai</span>
                          <div className="space-y-2 font-mono text-xs">
                            <div className="flex justify-between items-center bg-slate-950/20 p-2 rounded-lg border border-slate-900/60">
                              <span className="text-slate-500 text-[10px]">Ngày giao việc (Start):</span>
                              <span className="font-extrabold text-slate-300">{selectedTask.start_date || selectedTask.createdAt?.split('T')[0] || '2026-06-12'}</span>
                            </div>
                            <div className="flex justify-between items-center bg-slate-950/20 p-2 rounded-lg border border-slate-900/60">
                              <span className="text-slate-500 text-[10px]">Hạn hoàn thành (Due):</span>
                              <span className="font-extrabold text-indigo-400">{selectedTask.dueDate}</span>
                            </div>
                          </div>
                        </div>

                        <div>
                          <span className="text-slate-500 text-[10px] uppercase font-mono font-bold block mb-1.5 tracking-wider">KPI Weight & SLA Target</span>
                          <div className="grid grid-cols-2 gap-2 font-mono text-xs">
                            <div className="bg-slate-950/20 p-2 rounded-lg border border-slate-900/60">
                              <span className="text-slate-500 text-[10px] block">Khối Lượng</span>
                              <span className="font-extrabold text-slate-200 mt-0.5 block">{selectedTask.estimated_hours || 8} Giờ</span>
                            </div>
                            <div className="bg-slate-950/20 p-2 rounded-lg border border-slate-900/60">
                              <span className="text-slate-500 text-[10px] block">KPI Points</span>
                              <span className="font-extrabold text-emerald-400 mt-0.5 block">+{selectedTask.KPI_weight || 50}đ</span>
                            </div>
                          </div>
                          
                          <div className="mt-2 bg-slate-950/20 p-2 rounded-lg border border-slate-900/60 flex justify-between items-center font-mono text-xs">
                            <span className="text-slate-500 text-[10px]">SLA LEVEL ID:</span>
                            <span className={`font-extrabold block uppercase text-[10px] ${
                              selectedTask.SLA_level === 'critical' ? 'text-rose-400 animate-pulse' :
                              selectedTask.SLA_level === 'high' ? 'text-amber-400' : 'text-slate-400'
                            }`}>{selectedTask.SLA_level || 'medium'}</span>
                          </div>

                          {/* Checkpoint / KPI Points Approval Widget */}
                          <div className="mt-2 bg-slate-950/20 p-2.5 rounded-lg border border-slate-900/60 flex flex-col justify-center space-y-1">
                            <span className="text-slate-500 text-[9px] font-mono tracking-wider block">XÁC NHẬN ĐIỂM SỐ KPI:</span>
                            <div className="flex items-center justify-between mt-1 gap-2">
                              {selectedTask.KPI_confirmed ? (
                                <span className="text-[9px] text-emerald-400 font-extrabold bg-emerald-500/10 px-1.5 py-0.5 rounded border border-emerald-500/20 flex items-center gap-1 shrink-0">
                                  <CheckSquare className="w-2.5 h-2.5 text-emerald-400" />
                                  <span>Đã quyết toán</span>
                                </span>
                              ) : (
                                <span className="text-[9px] text-rose-400 font-bold bg-rose-500/10 px-1.5 py-0.5 rounded border border-rose-500/20 flex items-center gap-1 shrink-0">
                                  <ShieldAlert className="w-2.5 h-2.5 text-rose-500 animate-pulse" />
                                  <span>Chờ sếp duyệt</span>
                                </span>
                              )}
                              
                              {currentUser?.id === '1' && (
                                <button
                                  onClick={async () => {
                                    const nextConfirmed = !selectedTask.KPI_confirmed;
                                    const updated = { ...selectedTask, KPI_confirmed: nextConfirmed };
                                    await updateTask(updated);
                                    setSelectedTask(updated);
                                  }}
                                  className={`px-2 py-0.5 text-[8px] font-mono font-bold rounded border transition shrink-0 ${
                                    selectedTask.KPI_confirmed 
                                      ? 'bg-rose-950/40 border-rose-500/30 text-rose-400 hover:bg-rose-955'
                                      : 'bg-emerald-500 border-emerald-500 text-slate-950 font-extrabold hover:bg-emerald-400'
                                  }`}
                                >
                                  {selectedTask.KPI_confirmed ? "HỦY QUYẾT" : "PHÊ DUYỆT ĐIỂM ✅"}
                                </button>
                              )}
                            </div>
                          </div>

                        </div>
                      </div>

                    </div>

                    {/* Dependency badge check */}
                    {selectedTask.dependencies && selectedTask.dependencies.length > 0 && (
                      <div className="p-3 bg-yellow-500/10 border border-yellow-500/20 rounded-xl space-y-1">
                        <span className="text-[10px] font-mono font-bold text-yellow-500 uppercase tracking-wide">QUY TRÌNH PHỤ THUỘC (DEPENDENCY CHAIN):</span>
                        <p className="text-xs text-slate-400">Tác vụ này yêu cầu hoàn thành đầu việc: <strong>{selectedTask.dependencies[0]}</strong> trước khi kích hoạt giai đoạn sản xuất.</p>
                      </div>
                    )}

                    {/* Task descriptions */}
                    <div className="space-y-1.5 bg-slate-950/20 p-4 border border-slate-850 rounded-2xl">
                      <span className="text-[10px] font-mono text-slate-500 uppercase tracking-widest block font-bold">Mô tả tác vụ</span>
                      <p className="text-xs text-slate-300 leading-relaxed font-light whitespace-pre-wrap">{selectedTask.description}</p>
                    </div>

                    {/* Checklist / Subtasks section */}
                    <div className="space-y-3">
                      <span className="text-[10px] font-mono text-slate-500 uppercase tracking-widest block font-bold">Checklist tiến trình cụ thể</span>
                      
                      <div className="space-y-2">
                        {selectedTask.subtasks && selectedTask.subtasks.map(sub => (
                          <button
                            key={sub.id}
                            onClick={() => toggleSubtask(selectedTask.id, sub.id)}
                            className="w-full text-left p-2.5 bg-slate-950/40 border border-slate-850 hover:border-slate-805 rounded-xl flex items-center justify-between transition"
                          >
                            <div className="flex items-center gap-2.5">
                              <CheckSquare className={`w-4 h-4 ${sub.done ? 'text-emerald-400' : 'text-slate-600'}`} />
                              <span className={`text-xs ${sub.done ? 'line-through text-slate-500' : 'text-slate-200'}`}>{sub.title}</span>
                            </div>
                            <span className="text-[9px] font-mono text-slate-500">{sub.done ? 'Done' : 'Pending'}</span>
                          </button>
                        ))}
                      </div>

                      <div className="flex gap-2">
                        <input
                          type="text"
                          value={subtaskInput}
                          onChange={(e) => setSubtaskInput(e.target.value)}
                          placeholder="Bổ sung bước hành động tiếp..."
                          className="flex-1 bg-[#111726]/60 border border-slate-800 rounded-lg text-xs px-3 py-1.5 focus:border-emerald-500 focus:outline-none text-slate-200"
                        />
                        <button
                          onClick={() => {
                            if (!subtaskInput.trim()) return;
                            addSubtask(selectedTask.id, subtaskInput);
                            setSubtaskInput('');
                          }}
                          className="px-4 py-1.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-xs font-bold rounded-lg transition"
                        >
                          Bổ Sung
                        </button>
                      </div>
                    </div>

                    {/* Status Update slider */}
                    <div className="space-y-3 pt-3 border-t border-slate-850">
                      <span className="text-[10px] font-mono text-slate-500 uppercase tracking-widest block font-bold">Cập Nhật Trạng Thái</span>
                      <div className="flex gap-2">
                        {['todo', 'in_progress', 'backlog', 'done'].map((status) => (
                          <button
                            key={status}
                            onClick={() => {
                              updateTask({ 
                                ...selectedTask, 
                                status: status as any,
                                progress: status === 'done' ? 100 : selectedTask.progress
                              });
                              setSelectedTask({
                                ...selectedTask,
                                status: status as any,
                                progress: status === 'done' ? 100 : selectedTask.progress
                              });
                            }}
                            className={`flex-1 py-2 text-[10px] font-mono font-bold rounded-lg uppercase tracking-wide border transition ${
                              selectedTask.status === status
                                ? 'bg-emerald-500 border-emerald-500 text-slate-950 font-extrabold shadow-[0_0_10px_rgba(16,185,129,0.2)]'
                                : 'bg-slate-950 border-slate-850 text-slate-400 hover:text-white'
                            }`}
                          >
                            {status}
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Comments exchange */}
                    <div className="space-y-4 pt-3 border-t border-slate-850">
                      <span className="text-[10px] font-mono text-slate-500 uppercase tracking-widest block font-bold">Kênh Trao Đổi Phản Hồi</span>
                      
                      <div className="space-y-2 max-h-[150px] overflow-y-auto pr-1">
                        {selectedTask.comments && selectedTask.comments.map(c => (
                          <div key={c.id} className="p-3 bg-slate-950/40 border border-slate-850 rounded-xl text-xs space-y-1">
                            <div className="flex justify-between text-[10px] font-mono">
                              <span className="font-extrabold text-indigo-300">{c.userName}</span>
                              <span className="text-slate-500">{new Date(c.createdAt).toLocaleDateString('vi-VN')}</span>
                            </div>
                            <p className="text-slate-300 font-light">{c.content}</p>
                          </div>
                        ))}
                      </div>

                      <div className="flex gap-2">
                        <input
                          type="text"
                          value={commentInput}
                          onChange={(e) => setCommentInput(e.target.value)}
                          placeholder="Viết phản hồi hoặc tag thành viên..."
                          className="flex-1 bg-[#111726]/60 border border-slate-800 rounded-lg text-xs px-3 py-1.5 focus:border-emerald-500 focus:outline-none text-slate-200"
                        />
                        <button
                          onClick={() => {
                            if (!commentInput.trim()) return;
                            addComment(selectedTask.id, { userName: currentUser.name, content: commentInput });
                            setCommentInput('');
                          }}
                          className="p-2 px-4 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold rounded-lg text-xs transition"
                        >
                          Gửi
                        </button>
                      </div>
                    </div>
                  </>
                )}

              </div>

              {/* Modal Footer */}
              <div className="bg-slate-900 px-6 py-4 border-t border-slate-800 flex justify-between items-center gap-3">
                <div className="flex gap-2">
                  <button
                    onClick={() => {
                      if (window.confirm("Xóa vĩnh viễn tác vụ này?")) {
                        deleteTask(selectedTask.id);
                        setSelectedTask(null);
                      }
                    }}
                    className="px-3.5 py-1.5 bg-rose-500/10 text-rose-400 border border-rose-500/20 rounded-lg text-xs font-bold hover:bg-rose-500 hover:text-white transition"
                  >
                    Xóa Tác Vụ
                  </button>
                  
                  <button
                    onClick={() => setIsEditingTask(!isEditingTask)}
                    type="button"
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 border ${
                      isEditingTask 
                        ? 'bg-amber-500/10 border-amber-500/30 text-amber-400 hover:bg-amber-500 hover:text-slate-950' 
                        : 'bg-indigo-500/10 border-indigo-505 text-indigo-400 hover:bg-indigo-500 hover:text-slate-950'
                    }`}
                  >
                    {isEditingTask ? 'Hủy Bỏ Sửa' : 'Chỉnh Sửa Tác Vụ'}
                  </button>
                </div>

                <div className="flex gap-2">
                  {isEditingTask && (
                    <button
                      onClick={async () => {
                        const updatedTaskObj: Task = {
                          ...selectedTask,
                          title: editTitle,
                          description: editDesc,
                          department: editDept,
                          assignedTo: editAssignee,
                          priority: editPriority,
                          dueDate: editDueDate,
                          start_date: editStartDate,
                          estimated_hours: Number(editEstHours),
                          KPI_weight: Number(editKpiWeight),
                          SLA_level: editSlaLevel,
                          followers: editFollowers,
                          creator: editCreator,
                        };
                        await updateTask(updatedTaskObj);
                        setSelectedTask(updatedTaskObj);
                        setIsEditingTask(false);
                      }}
                      className="px-5 py-1.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-extrabold text-xs rounded-lg transition"
                    >
                      Lưu Thay Đổi
                    </button>
                  )}
                  <button
                    onClick={() => setSelectedTask(null)}
                    className="px-4 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold rounded-lg"
                  >
                    Đóng Console
                  </button>
                </div>
              </div>

            </div>
          </div>
        );
      })()}

      {/* 6. GORGEOUS TASK CREATION MODAL */}
      {showCreateModal && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-xs flex items-center justify-center p-4 z-50 overflow-y-auto">
          <form onSubmit={handleCreateTask} className="bg-[#0f1422] border border-slate-800 w-full max-w-xl rounded-2xl shadow-2xl overflow-hidden block">
            
            <div className="bg-slate-900 p-5 border-b border-slate-800 flex justify-between items-center">
              <span className="font-extrabold text-sm text-slate-100 font-display">TẠO NHIỆM VỤ ĐỘT PHÁ MỚI</span>
              <button type="button" onClick={() => setShowCreateModal(false)} className="text-slate-500 hover:text-white">✕</button>
            </div>

            <div className="p-6 space-y-4 text-xs font-mono">
              <div>
                <label className="block text-[10px] text-slate-500 uppercase font-bold mb-1">TÊN NHIỆM VỤ / KỊCH BẢN *</label>
                <input
                  type="text"
                  required
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  placeholder="Vd: Xây dựng bypass proxy Ngrok cho máy sếp"
                  className="w-full bg-[#111726]/60 border border-slate-800 rounded-lg py-2 px-3 text-slate-200 focus:border-emerald-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-[10px] text-slate-500 uppercase font-bold mb-1">CHI TIẾT PHÂN VIỆC *</label>
                <textarea
                  required
                  value={newDesc}
                  onChange={(e) => setNewDesc(e.target.value)}
                  placeholder="Cụ thể yêu cầu của sếp Tuấn Anh phòng tăng trưởng..."
                  className="w-full bg-[#111726]/60 border border-slate-800 rounded-lg py-2 px-3 h-20 text-slate-200 focus:border-emerald-500 focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-[10px] text-slate-500 uppercase font-bold mb-1">BỘ PHẬN ĐẢM TRÁCH</label>
                  <select
                    value={newDept}
                    onChange={(e) => setNewDept(e.target.value)}
                    className="w-full bg-[#111726] border border-slate-800 rounded-lg py-2 px-3 text-slate-300"
                  >
                    <option value="CRO Tăng Trưởng">CRO Tăng Trưởng</option>
                    <option value="Phát Triển Kỹ Thuật">Phát Triển Kỹ Thuật</option>
                    <option value="Tối Ưu Phễu">Tối Ưu Phễu</option>
                    <option value="Dịch Vụ Khách Hàng">Dịch Vụ Khách Hàng</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[10px] text-slate-500 uppercase font-bold mb-1">NHÂN SỰ PHỎNG ĐỊNH</label>
                  <select
                    value={newAssignee}
                    onChange={(e) => setNewAssignee(e.target.value)}
                    className="w-full bg-[#111726] border border-slate-800 rounded-lg py-2 px-3 text-slate-300"
                  >
                    {Array.from(new Map(users.map(u => [u.id, u])).values()).map(u => (
                      <option key={u.id} value={u.name}>{u.name}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-[10px] text-slate-500 uppercase font-bold mb-1">ĐỘ KHẨN CẤP (PRIORITY)</label>
                  <select
                    value={newPriority}
                    onChange={(e: any) => setNewPriority(e.target.value)}
                    className="w-full bg-[#111726] border border-slate-800 rounded-lg py-2 px-3 text-slate-300"
                  >
                    <option value="low">LOW</option>
                    <option value="medium">MEDIUM</option>
                    <option value="high">HIGH</option>
                    <option value="critical">CRITICAL</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[10px] text-slate-500 uppercase font-bold mb-1">SLA LEVEL</label>
                  <select
                    value={newSlaLevel}
                    onChange={(e: any) => setNewSlaLevel(e.target.value)}
                    className="w-full bg-[#111726] border border-slate-800 rounded-lg py-2 px-3 text-slate-300"
                  >
                    <option value="low">LOW</option>
                    <option value="medium">MEDIUM</option>
                    <option value="high">HIGH</option>
                    <option value="critical">CRITICAL</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-[10px] text-slate-500 uppercase font-bold mb-1">ƯỚC LƯỢNG GIỜ CÔNG (EST HOURLY)</label>
                  <input
                    type="number"
                    value={newEstHours}
                    onChange={(e) => setNewEstHours(Number(e.target.value))}
                    className="w-full bg-[#111726]/60 border border-slate-800 rounded-lg py-2 px-3 text-slate-200"
                  />
                </div>

                <div>
                  <label className="block text-[10px] text-slate-500 uppercase font-bold mb-1">
                    KPI WEIGHT CO-EFFICIENT 
                    {currentUser?.id !== '1' && <span className="text-rose-500 font-bold ml-1">(Chỉ Sếp sửa)</span>}
                  </label>
                  <input
                    type="number"
                    value={newKpiWeight}
                    onChange={(e) => setNewKpiWeight(Number(e.target.value))}
                    disabled={currentUser?.id !== '1'}
                    className="w-full bg-[#111726]/60 border border-slate-800 rounded-lg py-2 px-3 text-slate-200 disabled:opacity-50 disabled:cursor-not-allowed"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[10px] text-slate-500 uppercase font-bold mb-1">PHỤ THUỘC TÁC VỤ (DEPENDS ON)</label>
                <select
                  value={newDependency}
                  onChange={(e) => setNewDependency(e.target.value)}
                  className="w-full bg-[#111726] border border-slate-800 rounded-lg py-2 px-3 text-slate-300"
                >
                  <option value="">Không phụ thuộc đầu việc nào</option>
                  {tasks.map(t => (
                    <option key={t.id} value={t.id}>{t.title}</option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-[10px] text-slate-500 uppercase font-bold mb-1">NGÀY BẮT ĐẦU (START DATE)</label>
                  <input
                    type="date"
                    value={newStartDate}
                    onChange={(e) => setNewStartDate(e.target.value)}
                    className="w-full bg-[#111726]/60 border border-slate-800 rounded-lg py-2 px-3 text-slate-200"
                  />
                </div>

                <div>
                  <label className="block text-[10px] text-slate-500 uppercase font-bold mb-1">HẠN HOÀN THÀNH (DUE DATE)</label>
                  <input
                    type="date"
                    value={newDueDate}
                    onChange={(e) => setNewDueDate(e.target.value)}
                    className="w-full bg-[#111726]/60 border border-slate-800 rounded-lg py-2 px-3 text-slate-200"
                  />
                </div>
              </div>

            </div>

            <div className="bg-slate-900 px-6 py-4 border-t border-slate-800 flex justify-end gap-3">
              <button
                type="button"
                onClick={() => setShowCreateModal(false)}
                className="px-4 py-1.5 bg-slate-850 hover:bg-slate-800 text-slate-300 rounded-lg text-xs"
              >
                Hủy bỏ
              </button>
              <button
                type="submit"
                className="px-5 py-1.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-extrabold rounded-lg text-xs shadow-md transition"
              >
                XÁC NHẬN PHÂN VIỆC
              </button>
            </div>

          </form>
        </div>
      )}

    </div>
  );
}
