/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { User, Project, Department, Task } from '../types';
import { DB } from '../lib/dataStore';
import { Plus, FolderKanban, Info, CheckCircle2, TrendingUp, Filter, Trash2, Edit2, PlusCircle, CheckSquare, Clock, Calendar, CheckSquare as CheckIcon, Square } from 'lucide-react';

interface ProjectManagerProps {
  currentUser: User;
  projects: Project[];
  setProjects: (projects: Project[]) => void;
}

export default function ProjectManager({ currentUser, projects, setProjects }: ProjectManagerProps) {
  const isAuthorized = currentUser.id === '1' || currentUser.role === 'Super Admin' || currentUser.role === 'Admin' || currentUser.role === 'Manager' || currentUser.role === 'CEO / Quản lý tối cao' || currentUser.name.toLowerCase().includes('sếp');
  const [showCreateProj, setShowCreateProj] = useState(false);
  const [projName, setProjName] = useState('');
  const [projCode, setProjCode] = useState('');
  const [projDesc, setProjDesc] = useState('');
  const [projDept, setProjDept] = useState<Department>(currentUser.department || (Department ? Object.values(Department)[0] : 'MARKETING' as any));
  const [selectedDeptFilter, setSelectedDeptFilter] = useState<string>('All');

  // Load active lists
  const [allUsers, setAllUsers] = useState<User[]>([]);
  const [tasksList, setTasksList] = useState<Task[]>([]);

  // Editing Project States
  const [editingProj, setEditingProj] = useState<Project | null>(null);
  const [editProjName, setEditProjName] = useState('');
  const [editProjCode, setEditProjCode] = useState('');
  const [editProjDesc, setEditProjDesc] = useState('');
  const [editProjDept, setEditProjDept] = useState<Department>(Department ? Object.values(Department)[0] : 'MARKETING' as any);
  const [editProjStatus, setEditProjStatus] = useState<any>('planning');
  const [editProjProgress, setEditProjProgress] = useState(0);

  // New Related Task States
  const [selectedProjForTask, setSelectedProjForTask] = useState<string | null>(null);
  const [newTaskTitle, setNewTaskTitle] = useState('');
  const [newTaskDesc, setNewTaskDesc] = useState('');
  const [newTaskPriority, setNewTaskPriority] = useState<'low' | 'medium' | 'high' | 'critical'>('medium');
  const [newTaskStatus, setNewTaskStatus] = useState<'todo' | 'in_progress' | 'done'>('todo');
  const [newTaskAssignee, setNewTaskAssignee] = useState('');
  const [newTaskDueDate, setNewTaskDueDate] = useState('');

  const [aiChecklistGenerating, setAiChecklistGenerating] = useState(false);

  const depts = Department ? Object.values(Department) : [] as any;

  // Refresh data on mount
  useEffect(() => {
    refreshData();
  }, []);

  const refreshData = () => {
    DB.getUsers().then(u => {
      setAllUsers(u);
      if (u.length > 0) {
        setNewTaskAssignee(u[0].name);
      }
    });
    DB.getTasks().then(t => {
      setTasksList(t);
    });
  };

  const handleCreateProject = (e: React.FormEvent) => {
    e.preventDefault();
    if (!projName || !projCode) return;

    const newProject: Project = {
      id: 'p_' + Date.now(),
      name: projName,
      code: projCode.toUpperCase(),
      description: projDesc,
      progress: 0,
      department: projDept,
      status: 'planning',
      manager: currentUser.name,
      startDate: new Date().toISOString().split('T')[0],
      endDate: new Date(Date.now() + 30 * 24 * 3600 * 1000).toISOString().split('T')[0]
    } as any;

    const updated = [...projects, newProject];
    setProjects(updated);
    DB.saveProjects(updated);

    // Clear form
    setProjName('');
    setProjCode('');
    setProjDesc('');
    setShowCreateProj(false);
  };

  const handleStartEdit = (proj: any) => {
    setEditingProj(proj);
    setEditProjName(proj.name);
    setEditProjCode(proj.code || '');
    setEditProjDesc(proj.description || '');
    setEditProjDept(proj.department || (depts[0] as any));
    setEditProjStatus(proj.status);
    setEditProjProgress(proj.progress || 0);
  };

  const handleSaveEditProject = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingProj || !editProjName) return;

    const updated = projects.map(p => {
      if (p.id === editingProj.id) {
        return {
          ...p,
          name: editProjName,
          code: editProjCode.toUpperCase(),
          description: editProjDesc,
          department: editProjDept,
          status: editProjStatus,
          progress: editProjProgress
        };
      }
      return p;
    });

    setProjects(updated);
    DB.saveProjects(updated);
    setEditingProj(null);
  };

  const handleDeleteProj = (id: string) => {
    const proj = projects.find(p => p.id === id);
    const name = proj ? proj.name : 'Dự án';
    if (!window.confirm(`Sếp có chắc chắn muốn xóa dự án "${name}" vĩnh viễn? Tất cả đầu việc đi kèm sản xuất sẽ bị loại bỏ!`)) {
      return;
    }
    const updated = projects.filter(p => p.id !== id);
    setProjects(updated);
    DB.saveProjects(updated);
    DB.deleteProject(id);
    
    // Unlink tasks
    const unlinkedTasks = tasksList.map(t => {
      if (t.projectId === id) {
        return { ...t, projectId: '' };
      }
      return t;
    });
    setTasksList(unlinkedTasks);
    DB.saveTasks(unlinkedTasks);
  };

  const handleCreateRelatedTask = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTaskTitle || !selectedProjForTask) return;

    // AI automatic checklist generation based on task content & title
    setAiChecklistGenerating(true);
    let generatedChecklist: { id: string; title: string; done: boolean }[] = [];

    // Simulate AI Checklist Generator
    const prompts = [
      `Kiểm tra chất lượng phôi in cho ${newTaskTitle}`,
      `Chuẩn sấy lò UV nhiệt độ phòng xưởng`,
      `Chạy mẫu decal thử và bàn giao lãnh đạo`,
      `In hàng loạt & đóng màng hoàn thiện`
    ];
    generatedChecklist = prompts.map((p, i) => ({
      id: `check_${Date.now()}_${i}`,
      title: p,
      done: false
    }));

    const newTask: Task = {
      id: 'task_' + Date.now(),
      title: newTaskTitle,
      description: newTaskDesc,
      status: newTaskStatus,
      priority: newTaskPriority,
      dueDate: newTaskDueDate || new Date(Date.now() + 7 * 24 * 3600 * 1000).toISOString().split('T')[0],
      assignedTo: newTaskAssignee,
      projectId: selectedProjForTask,
      progress: 0,
      subtasks: generatedChecklist,
      attachments: [],
      comments: [],
      activity_logs: [
        {
          id: 'log_' + Date.now(),
          action: 'Khởi tạo qua Dự án Chiến dịch',
          performedBy: currentUser.name,
          timestamp: new Date().toISOString()
        }
      ]
    };

    const updatedTasks = [newTask, ...tasksList];
    setTasksList(updatedTasks);
    await DB.saveTask(newTask);

    // Save automatic notification
    const newNotif = {
      id: 'notif_' + Date.now(),
      title: 'Tác vụ mới liên quan dự án',
      message: `Cán sự ${newTaskAssignee} được phân công việc "${newTaskTitle}" liên kết dự án chiến dịch mới.`,
      type: 'info' as const,
      read: false,
      timestamp: new Date().toISOString()
    };
    await DB.saveNotification(newNotif);

    // Clean up
    setNewTaskTitle('');
    setNewTaskDesc('');
    setSelectedProjForTask(null);
    setAiChecklistGenerating(false);
    refreshData();
  };

  const toggleSubtaskStatus = async (taskId: string, subtaskId: string) => {
    const updated = tasksList.map(t => {
      if (t.id === taskId) {
        const subtasks = (t.subtasks || []).map(s => {
          if (s.id === subtaskId) return { ...s, done: !s.done };
          return s;
        });
        const completed = subtasks.filter(s => s.done).length;
        const progress = subtasks.length > 0 ? Math.round((completed / subtasks.length) * 100) : t.progress;
        
        const nextTask = {
          ...t,
          subtasks,
          progress,
          status: progress === 100 ? 'done' as const : t.status
        };
        DB.saveTask(nextTask);
        return nextTask;
      }
      return t;
    });
    setTasksList(updated);
  };

  const handleProgressChange = (id: string, nextProgress: number) => {
    const updated = projects.map(p => {
      if (p.id === id) return { ...p, progress: nextProgress };
      return p;
    });
    setProjects(updated);
    DB.saveProjects(updated);
  };

  const handleUpdateStatus = (id: string, nextStatus: any) => {
    const updated = projects.map(p => {
      if (p.id === id) return { ...p, status: nextStatus };
      return p;
    });
    setProjects(updated);
    DB.saveProjects(updated);
  };

  const filteredProjects = projects.filter(p => {
    if (selectedDeptFilter !== 'All' && p.department !== selectedDeptFilter) return false;
    return true;
  });

  return (
    <div className="space-y-6 max-w-7xl mx-auto p-4 md:p-6 lg:p-8 font-sans">
      
      {/* Page Title */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-xl md:text-2xl font-bold text-slate-900 dark:text-white font-display uppercase tracking-tight flex items-center gap-2">
            <FolderKanban className="w-6 h-6 text-blue-600" />
            <span>Chiến dịch & Dự án Tổng</span>
          </h1>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            Quản trị & khởi tạo dự án sản xuất, in ấn tem nhãn sấy dính công suất lớn Vivian Decal.
          </p>
        </div>

        {/* Create button */}
        {isAuthorized && (
          <button
            onClick={() => setShowCreateProj(true)}
            className="w-full sm:w-auto py-2 px-4 bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold rounded-lg flex items-center justify-center gap-1.5 transition-all cursor-pointer shadow-md shadow-blue-500/10"
          >
            <Plus className="w-4 h-4" />
            <span>Thành lập Dự án Mới</span>
          </button>
        )}
      </div>

      {/* Filter line */}
      <div className="glass-card rounded-xl p-4 flex justify-between items-center text-xs">
        <div className="flex items-center gap-2">
          <Filter className="w-4 h-4 text-slate-400" />
          <span className="font-semibold text-slate-500">Bộ xưởng phòng ban liên kết:</span>
        </div>
        <select
          value={selectedDeptFilter}
          onChange={(e) => setSelectedDeptFilter(e.target.value)}
          className="glass-dropdown rounded-lg text-xs py-1.5 px-3 focus:outline-none"
        >
          <option value="All">Tất cả phòng ban</option>
          {depts.map((d: any) => (
            <option key={d} value={d}>{d}</option>
          ))}
        </select>
      </div>

      {/* Projects Grid List */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {filteredProjects.map((proj) => {
          const relatedTasks = tasksList.filter(t => t.projectId === proj.id);
          const doneTasks = relatedTasks.filter(t => t.status === 'done').length;

          return (
            <div
              key={proj.id}
              className="glass-card rounded-2xl p-5 space-y-4 border border-white/5 bg-white/5 dark:bg-slate-900/40 backdrop-blur"
            >
              <div className="flex justify-between items-start gap-3">
                <div className="flex items-start gap-3">
                  <div className="p-2.5 bg-blue-50 dark:bg-blue-950/40 text-blue-600 rounded-xl shrink-0">
                    <FolderKanban className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="font-bold text-sm text-slate-900 dark:text-white font-display leading-tight">{proj.name}</h3>
                    <span className="text-[10px] text-slate-400 font-mono block mt-0.5">
                      {proj.id.substring(0, 8).toUpperCase()} • Phòng {proj.department || 'Vivian'}
                    </span>
                  </div>
                </div>

                {/* Status Select Badge */}
                <div className="flex items-center gap-1.5">
                  <span className={`text-[10px] uppercase font-bold px-2.5 py-1 rounded-lg ${
                    proj.status === 'completed' 
                      ? 'bg-emerald-500/10 text-emerald-400' 
                      : proj.status === 'ongoing' || proj.status === 'active'
                      ? 'bg-blue-500/10 text-blue-400'
                      : proj.status === 'on_hold' || proj.status === 'on-hold'
                      ? 'bg-amber-500/10 text-amber-400'
                      : 'bg-slate-500/10 text-slate-400'
                  }`}>
                    {proj.status === 'completed' ? 'Đã hoàn thành' : proj.status === 'active' || proj.status === 'ongoing' ? 'Đang chạy' : proj.status === 'on_hold' || proj.status === 'on-hold' ? 'Tạm giữ' : 'Kế hoạch'}
                  </span>

                  {/* Edit project */}
                  {isAuthorized && (
                    <button
                      onClick={() => handleStartEdit(proj)}
                      className="p-1.5 text-slate-400 hover:text-slate-100 hover:bg-slate-800/40 rounded cursor-pointer border-none transition-colors"
                      title="Sửa dự án"
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                    </button>
                  )}

                  {/* Trash delete project */}
                  {isAuthorized && (
                    <button
                      onClick={() => handleDeleteProj(proj.id)}
                      className="p-1.5 text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/25 rounded cursor-pointer border-none transition-colors"
                      title="Xóa dự án"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              </div>

              <p className="text-xs text-slate-500 dark:text-slate-400 font-light leading-relaxed min-h-[30px]">
                {proj.description || 'Chưa cập nhật tài liệu mô tả mục tiêu xưởng.'}
              </p>

              {/* Tasks linked display */}
              <div className="p-3.5 bg-slate-100/50 dark:bg-slate-950/30 rounded-xl space-y-3">
                <div className="flex justify-between items-center text-xs">
                  <span className="font-semibold text-slate-700 dark:text-slate-350 flex items-center gap-1.5">
                    <CheckSquare className="w-4 h-4 text-emerald-500" />
                    Danh sách việc trong dự án ({relatedTasks.length} việc)
                  </span>
                  
                  <button
                    onClick={() => setSelectedProjForTask(proj.id)}
                    className="text-[10px] text-blue-600 dark:text-blue-400 font-bold hover:underline flex items-center gap-1"
                  >
                    <PlusCircle className="w-3 h-3" />
                    Giao việc liên quan
                  </button>
                </div>

                {relatedTasks.length === 0 ? (
                  <p className="text-[10px] text-slate-400 italic">Dự án này chưa được phân bổ tác vụ sản xuất liên quan.</p>
                ) : (
                  <div className="space-y-1.5 max-h-[150px] overflow-y-auto scrollbar select-none">
                    {relatedTasks.map(t => (
                      <div key={t.id} className="p-2.5 bg-white dark:bg-slate-900/30 rounded-lg border border-slate-200/50 dark:border-slate-800 flex justify-between items-center text-[11px]">
                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => {
                              const updatedStatus = t.status === 'done' ? 'todo' : 'done';
                              const nextT = { ...t, status: updatedStatus as any, progress: updatedStatus === 'done' ? 100 : 0 };
                              DB.saveTask(nextT).then(() => refreshData());
                            }}
                            className="text-slate-400 hover:text-emerald-500 transition-all border-none bg-transparent"
                          >
                            {t.status === 'done' ? (
                              <CheckIcon className="w-4 h-4 text-emerald-500 fill-emerald-500/10" />
                            ) : (
                              <Square className="w-4 h-4 text-slate-400 dark:text-slate-600" />
                            )}
                          </button>
                          <div className={t.status === 'done' ? 'line-through text-slate-450' : 'text-slate-750 dark:text-slate-200 font-medium'}>
                            {t.title}
                            <span className="text-[9px] text-slate-400 block font-mono">Phụ trách: {t.assignedTo}</span>
                          </div>
                        </div>

                        {/* Checklist items list */}
                        {t.subtasks && t.subtasks.length > 0 && (
                          <div className="flex items-center gap-1 text-[9px] text-slate-400 font-mono">
                            <span>({t.subtasks.filter(s => s.done).length}/{t.subtasks.length}) Checklist</span>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Completion dynamic bar */}
              <div className="space-y-1.5 pt-2">
                <div className="flex justify-between text-xs text-slate-500 dark:text-slate-400">
                  <span className="font-semibold">Tiến độ lũy tiến</span>
                  <span className="font-bold text-blue-600 font-mono">{proj.progress || 0}%</span>
                </div>
                <div className="h-2 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden flex">
                  <div 
                    className="bg-gradient-to-r from-blue-500 to-indigo-600 h-full transition-all" 
                    style={{ width: `${proj.progress || 0}%` }} 
                  />
                </div>

                {/* Progress slider handle if Admin */}
                {isAuthorized && (
                  <div className="flex items-center gap-2 pt-2 text-[10px]">
                    <span className="text-slate-400">Cân chỉnh nhanh:</span>
                    <input
                      type="range"
                      min={0}
                      max={100}
                      value={proj.progress || 0}
                      onChange={(e) => handleProgressChange(proj.id, parseInt(e.target.value))}
                      className="flex-1 accent-blue-600 h-1 rounded bg-slate-200 dark:bg-slate-800"
                    />
                  </div>
                )}
              </div>

            </div>
          );
        })}
      </div>

      {/* Project Creation Popup */}
      {showCreateProj && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-md flex items-center justify-center p-4 z-50 animate-fade-in">
          <form onSubmit={handleCreateProject} className="glass-card w-full max-w-sm rounded-2xl overflow-hidden block shadow-2xl">
            
            <div className="p-4 border-b border-white/5 bg-white/5 dark:bg-black/20 flex justify-between items-center">
              <span className="font-bold text-xs uppercase tracking-wider text-slate-700 dark:text-slate-300 font-display">Phê duyệt Dự Án Mới</span>
              <button
                type="button"
                onClick={() => setShowCreateProj(false)}
                className="text-slate-450 hover:text-slate-700 bg-transparent border-none text-sm font-bold"
              >
                ✕
              </button>
            </div>

            <div className="p-5 space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-550 dark:text-slate-400 mb-1.5">Tên chiến dịch / Máy xưởng</label>
                <input
                  type="text"
                  required
                  value={projName}
                  onChange={(e) => setProjName(e.target.value)}
                  placeholder="Ví dụ: Thiết kế decal UV sấy nhãn sấy dính"
                  className="w-full glass-input text-xs px-3.5 py-2.5 rounded-lg focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-550 dark:text-slate-400 mb-1.5">Mã viết tắt</label>
                  <input
                    type="text"
                    required
                    value={projCode}
                    onChange={(e) => setProjCode(e.target.value)}
                    placeholder="VD: DECAL-UV"
                    className="w-full glass-input text-xs px-3.5 py-2.5 rounded-lg focus:outline-none focus:border-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-550 dark:text-slate-400 mb-1.5">Phòng ban liên quan</label>
                  <select
                    value={projDept}
                    onChange={(e) => setProjDept(e.target.value as Department)}
                    className="w-full glass-dropdown text-xs px-3.5 py-2.5 rounded-lg"
                  >
                    {depts.map((d: any) => (
                      <option key={d} value={d}>{d}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-550 dark:text-slate-400 mb-1.5">Bản mô tả mục tiêu dự án</label>
                <textarea
                  value={projDesc}
                  onChange={(e) => setProjDesc(e.target.value)}
                  rows={3}
                  className="w-full glass-input text-xs px-3.5 py-2.5 rounded-lg focus:outline-none focus:border-blue-500"
                  placeholder="Mục tiêu sấy mác decal công nghiệp tự động..."
                />
              </div>

            </div>

            <div className="p-4 border-t border-white/5 bg-white/5 dark:bg-black/20 flex justify-end gap-2 text-xs">
              <button
                type="button"
                onClick={() => setShowCreateProj(false)}
                className="px-4 py-2 bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-350 rounded-lg cursor-pointer"
              >
                Hủy bỏ
              </button>
              <button
                type="submit"
                className="px-5 py-2 bg-blue-600 text-white font-semibold rounded-lg hover:bg-blue-700 cursor-pointer"
              >
                Tạo dự án
              </button>
            </div>

          </form>
        </div>
      )}

      {/* Editing Project Popup */}
      {editingProj && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-md flex items-center justify-center p-4 z-50 animate-fade-in">
          <form onSubmit={handleSaveEditProject} className="glass-card w-full max-w-sm rounded-2xl overflow-hidden block shadow-2xl">
            
            <div className="p-4 border-b border-white/5 bg-white/5 dark:bg-black/20 flex justify-between items-center">
              <span className="font-bold text-xs uppercase tracking-wider text-slate-700 dark:text-slate-300 font-display">Sửa thông tin dự án</span>
              <button
                type="button"
                onClick={() => setEditingProj(null)}
                className="text-slate-450 hover:text-slate-700 bg-transparent border-none text-sm font-bold"
              >
                ✕
              </button>
            </div>

            <div className="p-5 space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-550 dark:text-slate-400 mb-1.5">Tên chiến dịch / Bộ máy</label>
                <input
                  type="text"
                  required
                  value={editProjName}
                  onChange={(e) => setEditProjName(e.target.value)}
                  className="w-full glass-input text-xs px-3.5 py-2.5 rounded-lg focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-550 dark:text-slate-400 mb-1.5">Mã code</label>
                  <input
                    type="text"
                    required
                    value={editProjCode}
                    onChange={(e) => setEditProjCode(e.target.value)}
                    className="w-full glass-input text-xs px-3.5 py-2.5 rounded-lg focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-550 dark:text-slate-400 mb-1.5">Phòng ban liên quan</label>
                  <select
                    value={editProjDept}
                    onChange={(e) => setEditProjDept(e.target.value as Department)}
                    className="w-full glass-dropdown text-xs px-3.5 py-2.5 rounded-lg"
                  >
                    {depts.map((d: any) => (
                      <option key={d} value={d}>{d}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-550 dark:text-slate-400 mb-1.5">Thành trạng dự án</label>
                  <select
                    value={editProjStatus}
                    onChange={(e) => setEditProjStatus(e.target.value as any)}
                    className="w-full glass-dropdown text-xs px-3.5 py-2.5 rounded-lg"
                  >
                    <option value="planning">Kế hoạch</option>
                    <option value="active">Đang kích hoạt</option>
                    <option value="completed">Đã bàn giao</option>
                    <option value="on-hold">Đang tạm dừng</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-550 dark:text-slate-400 mb-1.5">Tiến độ (%)</label>
                  <input
                    type="number"
                    min={0}
                    max={100}
                    value={editProjProgress}
                    onChange={(e) => setEditProjProgress(parseInt(e.target.value) || 0)}
                    className="w-full glass-input text-xs px-3.5 py-2.5 rounded-lg focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-550 dark:text-slate-400 mb-1.5">Bản mô tả mục tiêu dự án</label>
                <textarea
                  value={editProjDesc}
                  onChange={(e) => setEditProjDesc(e.target.value)}
                  rows={2}
                  className="w-full glass-input text-xs px-3.5 py-2.5 rounded-lg focus:outline-none"
                />
              </div>

            </div>

            <div className="p-4 border-t border-white/5 bg-white/5 dark:bg-black/20 flex justify-end gap-2 text-xs">
              <button
                type="button"
                onClick={() => setEditingProj(null)}
                className="px-4 py-2 bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-350 rounded-lg cursor-pointer"
              >
                Hủy bỏ
              </button>
              <button
                type="submit"
                className="px-5 py-2 bg-blue-600 text-white font-semibold rounded-lg hover:bg-blue-700 cursor-pointer"
              >
                Lưu chỉnh sửa
              </button>
            </div>

          </form>
        </div>
      )}

      {/* Task Creation Popup related to selected project */}
      {selectedProjForTask && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-md flex items-center justify-center p-4 z-50 animate-fade-in">
          <form onSubmit={handleCreateRelatedTask} className="glass-card w-full max-w-sm rounded-2xl overflow-hidden block shadow-2xl text-xs">
            
            <div className="p-4 border-b border-white/5 bg-white/5 dark:bg-black/20 flex justify-between items-center">
              <div>
                <span className="font-bold text-xs uppercase tracking-wider text-slate-750 dark:text-slate-250 font-display block">Giao việc dự án mới</span>
                <span className="text-[9px] text-slate-450 uppercase block font-mono">
                  DỰ ÁN LIÊN KẾT: {projects.find(p => p.id === selectedProjForTask)?.name}
                </span>
              </div>
              <button
                type="button"
                onClick={() => setSelectedProjForTask(null)}
                className="text-slate-450 hover:text-slate-700 bg-transparent border-none text-sm font-bold"
              >
                ✕
              </button>
            </div>

            <div className="p-5 space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-400 mb-1">Tiêu đề công việc cần giao</label>
                <input
                  type="text"
                  required
                  value={newTaskTitle}
                  onChange={(e) => setNewTaskTitle(e.target.value)}
                  placeholder="Ví dụ: Kiểm thử màng UV cho decal Vivian"
                  className="w-full glass-input text-xs px-3.5 py-2.5 rounded-lg focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-400 mb-1">Bản mô tả chi tiết nhiệm vụ sản xuất</label>
                <textarea
                  value={newTaskDesc}
                  onChange={(e) => setNewTaskDesc(e.target.value)}
                  rows={2}
                  placeholder="Mô tả công việc chi tiết. AI sẽ tự động sinh check-list xưởng chuẩn mực cho việc này dựa trên bộ phòng ban hệ thống..."
                  className="w-full glass-input text-xs px-3.5 py-2 rounded-lg focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-100 mb-1">Giao cho nhân sự xưởng</label>
                  <select
                    value={newTaskAssignee}
                    onChange={(e) => setNewTaskAssignee(e.target.value)}
                    className="w-full glass-dropdown text-xs px-3.5 py-2 rounded-lg"
                  >
                    {allUsers.map(u => (
                      <option key={u.id} value={u.name}>{u.name} ({u.role})</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-100 mb-1">Ưu tiên</label>
                  <select
                    value={newTaskPriority}
                    onChange={(e) => setNewTaskPriority(e.target.value as any)}
                    className="w-full glass-dropdown text-xs px-3.5 py-2 rounded-lg font-bold text-slate-650"
                  >
                    <option value="low">Thấp</option>
                    <option value="medium">Trung bình</option>
                    <option value="high">Cao</option>
                    <option value="critical">Khẩn cấp ⚡</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-400 mb-1">Hạn kết thúc</label>
                  <input
                    type="date"
                    required
                    value={newTaskDueDate}
                    onChange={(e) => setNewTaskDueDate(e.target.value)}
                    className="w-full glass-input text-[11px] px-3.5 py-1.5 rounded-lg"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-400 mb-1">Thành trạng ban đầu</label>
                  <select
                    value={newTaskStatus}
                    onChange={(e) => setNewTaskStatus(e.target.value as any)}
                    className="w-full glass-dropdown text-xs px-3.5 py-2 rounded-lg"
                  >
                    <option value="todo">Chờ làm</option>
                    <option value="in_progress">Đang làm</option>
                    <option value="done">Hoàn thành</option>
                  </select>
                </div>
              </div>

            </div>

            <div className="p-4 border-t border-white/5 bg-white/5 dark:bg-black/20 flex justify-end gap-2 text-xs">
              <button
                type="button"
                onClick={() => setSelectedProjForTask(null)}
                className="px-4 py-2 bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-350 rounded-lg cursor-pointer"
              >
                Hủy bỏ
              </button>
              <button
                type="submit"
                disabled={aiChecklistGenerating}
                className="px-5 py-2 bg-blue-600 text-white font-semibold rounded-lg hover:bg-blue-700 cursor-pointer disabled:opacity-50"
              >
                {aiChecklistGenerating ? 'AI đang sinh Checklist...' : 'Tạo việc liên quan'}
              </button>
            </div>

          </form>
        </div>
      )}

    </div>
  );
}
